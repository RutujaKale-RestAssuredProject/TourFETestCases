package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class PassengerDetailsPage {
	WebDriver driver;
	
    By FirstName = By.id("txtFirstNameNew");
    By LastName = By.id("txtLastNameNew");
	By Email = By.id("txtEmail");
	By Phone = By.id("txtPhNo");
	
	By TourName1 = By.xpath("(.//*[contains(text(),'Tour Option')]/following-sibling::div)[1]");
	By TransferType1 = By.xpath("(.//li/div[contains(text(),'Transfer Type')]/following-sibling::div)[1]");
	By BookingDate1 = By.xpath("(.//li/div[contains(text(),'Date')]/following-sibling::div)[1]");
	By BookingTime1 = By.xpath("(.//li/div[contains(text(),'Time')]/following-sibling::div)[1]");
	By PAX1 = By.xpath("(.//li/div[contains(text(),'Pax')]/following-sibling::div)[1]");
	By CancellationDate1 = By.xpath("(.//*[contains(text(),'Last date to Cancel :')]/following-sibling::div)[1]");
	By AmountTour1 = By.xpath("(.//*[contains(text(),'Total')]/following-sibling::div[@class='lblValuedark'])[1]");
	
	By TourName2 = By.xpath("(.//*[contains(text(),'Tour Option')]/following-sibling::div)[2]");
	By TransferType2 = By.xpath("(.//li/div[contains(text(),'Transfer Type')]/following-sibling::div)[2]");
	By BookingDate2 = By.xpath("(.//li/div[contains(text(),'Date')]/following-sibling::div)[2]");
	By BookingTime2 = By.xpath("(.//li/div[contains(text(),'Time')]/following-sibling::div)[2]");
	By PAX2 = By.xpath("(.//li/div[contains(text(),'Pax')]/following-sibling::div)[2]");
	By CancellationDate2 = By.xpath("(.//*[contains(text(),'Last date to Cancel :')]/following-sibling::div)[2]");
	By AmountTour2 = By.xpath("(.//*[contains(text(),'Total')]/following-sibling::div[@class='lblValuedark'])[2]");
	
	By FinalPayment = By.xpath(".//*[contains(text(),'Final Payment')]/following-sibling::p/span[2]");
	
	public PassengerDetailsPage (WebDriver d) {
		driver =d;
	}
		
	public void RadioButtonPayByCreditLimit () {
		driver.findElement(By.id("CreditLimit_licred")).click();
	}
	
	public void TermsConditions () {
		driver.findElement(By.className("checkmark")).click();
	}
	
	public void PassengerInfo () {		
		driver.findElement(FirstName).sendKeys("Sujit");
		System.out.println("First Name is given");
		driver.findElement(LastName).sendKeys("Patil");
		System.out.println("Last Name is given");	
		System.out.println(driver.findElement(Email).getText());
		System.out.println(driver.findElement(Phone).getText());
	}
	
	//Tour 1
	public void TourName1 () {
		System.out.println("Tour Name 1 = " + driver.findElement(TourName1).getText());
	}
	
	
	public void TransferType1 () {
		System.out.println("Transfer Type for Tour 1 = " + driver.findElement(TransferType1).getText());
	}
	
	public void BookingDate1 () {
		System.out.println("Booking Date for Tour 1  = " + driver.findElement(BookingDate1).getText());
	}
	
	public void BookingTime1 () {
		System.out.println("Booking Time for Tour 1  = " + driver.findElement(BookingTime1).getText());
	}
	
	public void PAX1 () {
		System.out.println("Number of Adults and Childs for Tour 1 = " + driver.findElement(PAX1).getText());
	}
	
	public void CancellationDate1 () {
		System.out.println("Cancellation Date is for Tour 1 = " + driver.findElement(CancellationDate1).getText());
	}

	public void AmountTour1() {
		System.out.println("Total Amount for Tour option 1 = " + driver.findElement(AmountTour1).getText());	
	}	
	
	//Tour 2
	
	public void TourName2 () {
		System.out.println("Tour Name 1 = " + driver.findElement(TourName2).getText());
	}
	
	public void TransferType2 () {
		System.out.println("Transfer Type for Tour 1 = " + driver.findElement(TransferType2).getText());
	}
	
	public void BookingDate2 () {
		System.out.println("Booking Date for Tour 1  = " + driver.findElement(BookingDate2).getText());
	}
	
	public void BookingTime2 () {
		System.out.println("Booking Time for Tour 1  = " + driver.findElement(BookingTime2).getText());
	}
	
	public void PAX2 () {
		System.out.println("Number of Adults and Childs for Tour 1 = " + driver.findElement(PAX2).getText());
	}
	
	public void CancellationDate2 () {
		System.out.println("Cancellation Date is for Tour 1 = " + driver.findElement(CancellationDate2).getText());
	}

	public void AmountTour2() {
		System.out.println("Total Amount for Tour option 1 = " + driver.findElement(AmountTour2).getText());	
	}

	public void FinalPayment() {
		System.out.println("Final Payment to be done for all tours = " + driver.findElement(FinalPayment).getText());	
	}


}
