package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class SalesInvoice {	
	WebDriver driver;

	public SalesInvoice (WebDriver d) {
		driver =d;
	}

	public void InvoiceLogo () {		
		System.out.println("Agent logo on top left corner is displayed on Invoice details page!");
		driver.findElement(By.xpath("(.//*[@class='logopart']/div[2])[2]/div/div/img")).isDisplayed();
		System.out.println("Rayna logo on top right corner is displayed on Invoice details page!");
	}

	public void ReferenceDetails() {
		System.out.println("Reference Number = " + driver.findElement(By.xpath("(.//*[@class='ref-details']/div/div/table/tbody/tr/td)[7]")).getText());
		System.out.println("Guest Name = " + driver.findElement(By.xpath("(.//*[@class='ref-details']/div/div/table/tbody/tr/td)[8]")).getText());
		System.out.println("Payment Type = " + driver.findElement(By.xpath("(.//*[@class='ref-details']/div/div/table/tbody/tr/td)[10]")).getText());
		System.out.println("Agent Email Id = " + driver.findElement(By.xpath("(.//*[@class='ref-details']/div/div/table/tbody/tr/td)[11]")).getText());
		System.out.println("Agent Mobile No. = " + driver.findElement(By.xpath("(.//*[@class='ref-details']/div/div/table/tbody/tr/td)[12]")).getText());	
	}

	public void ServiceType () {		
		System.out.println("Service Type = " + driver.findElement(By.xpath("(.//*[@class='servic']/div)[5]")).getText());
	} 

	public void TourDetails () {		
		System.out.println("Tour 1 Name = "
				+ driver.findElement(By.xpath("(.//*[@class='ht-name'])[2]"))
				.getText()
				+ " with price " + driver.findElement(By.xpath("((.//*[contains(text(),'Total Amount:')])[3]/following::tbody/tr/td)[5]")).getText() + " Dated = " + driver.findElement(By.xpath("((.//*[contains(text(),'Tour Date:')])[2]/following::td)[1]")).getText());
	} 

	//Cancellation Charges for Tours
	public void CancellationChargeForTour1 () {		
		System.out.println("The booking Cancellation Charges for Tour 1 =  "
				+ driver.findElement(By.xpath("((.//*[contains(text(),'Cancellation Charges')])[3]/following::td)[1]"))
				.getText()
				+ " is " + driver.findElement(By.xpath("((.//*[contains(text(),'Cancellation Charges')])[3]/following::td)[3]")).getText() + ", If you cancel the Booking FROM " + driver.findElement(By.xpath("((.//*[contains(text(),'Cancellation Charges')])[3]/following::td)[2]")).getText());
	} 

	//Cancellation Charges for Tours
	public void CancellationChargeForTour2 () {		
		System.out.println("The booking Cancellation Charges for Tour 1 =  "
				+ driver.findElement(By.xpath("(.//*[contains(text(),'Cancellation Charges')]/following::td)[4]"))
				.getText()
				+ " is " + driver.findElement(By.xpath("(.//*[contains(text(),'Cancellation Charges')]/following::td)[6]")).getText() + ", If you cancel the Booking FROM " + driver.findElement(By.xpath("(.//*[contains(text(),'Cancellation Charges')]/following::td)[5]")).getText());
	} 

	//close button
	public void Close () {		
		driver.findElement(By.xpath("(.//*[@class='modal-content']/button)[2]")).click();
	} 

}
