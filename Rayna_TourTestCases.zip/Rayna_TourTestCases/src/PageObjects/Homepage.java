package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Homepage {
	
	WebDriver driver;

	public Homepage (WebDriver d) {
		driver =d;
	}
	
	public void TourCity () {		
		driver.findElement(By.id("txtCityNameTour")).click();
		driver.findElement(By.xpath("(.//*[contains(text(),'Dubai City')])[1]")).click();
	}
	
	public void SearchButton () {		
		driver.findElement(By.id("btnTourSearch")).click();
	}
	
	
}
