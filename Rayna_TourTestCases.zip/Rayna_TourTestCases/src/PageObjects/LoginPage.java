package PageObjects;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import com.excel.lib.util.Xls_Reader;

public class LoginPage {
	WebDriver driver;

	public LoginPage (WebDriver d) {
		driver =d;
	}

	public void Login() {	
		WebElement Agent = driver.findElement(By.id("txtAgentcode"));
		WebElement userName = driver.findElement(By.id("txtUsername"));
		WebElement pwd = driver.findElement(By.id("txtPassword"));	

		Xls_Reader reader = new Xls_Reader("./src/ExcelResults/SampleExcel.xlsx");
		String sheetName = "login";

		int rowCount = reader.getRowCount(sheetName);

		for(int rowNum=2; rowNum<=rowCount; rowNum++){
			String AgentCode = reader.getCellData(sheetName, "Agent", rowNum);
			String loginId = reader.getCellData(sheetName, "username", rowNum);
			String passsword = reader.getCellData(sheetName, "password", rowNum);

			System.out.println(AgentCode + " " + loginId + " " + passsword);

			Agent.clear();
			Agent.sendKeys(AgentCode);

			userName.clear();
			userName.sendKeys(loginId);

			pwd.clear();
			pwd.sendKeys(passsword);
			driver.findElement(By.id("btnLogin")).click(); 
		}
	}
}
