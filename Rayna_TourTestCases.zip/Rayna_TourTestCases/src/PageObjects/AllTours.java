package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class AllTours {
	WebDriver driver;
	
	By DhowCruise = By.xpath(".//*[contains(text(),'Dhow Cruise Dinner - Creek')]");
	
	public AllTours (WebDriver d) {
		driver =d;
	}
	
	public void DhowCruiseDinner () {
		driver.findElement(DhowCruise).click();
		System.out.println("Dhow Cruise Dinner - Creek is clicked!");
	}

}
