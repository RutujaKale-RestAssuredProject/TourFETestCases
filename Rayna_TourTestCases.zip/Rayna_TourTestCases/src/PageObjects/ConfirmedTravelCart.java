package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ConfirmedTravelCart {
	
	WebDriver driver;
	
	public ConfirmedTravelCart(WebDriver d) {
		driver =d;
	}
	
	public void DonwloadInvoiceButton () {		
		driver.findElement(By.xpath("(.//*[contains(text(),'Download  invoice')])[1]")).click();
		System.out.println("Invoice is downloaded!");
	}
	
	public void ViewInvoice () {		
		driver.findElement(By.xpath("(.//*[contains(text(),'View invoice')])[1]")).click();
	}
			
	//Tour 1
	public void TourName1() {		
		System.out.println("Tour " + driver.findElement(By.xpath("(.//div[@class='module_ttle'])[1]")).getText() + " is Confirmed");
	}
	
	public void Price1() {		
		System.out.println("Price for Tour 1 = " + driver.findElement(By.xpath("(.//div[@class='grandprice'])[1]")).getText());
	}
	
	public void ConfirmedStatusTour1 () {		
		System.out.println("Booking Status for Tour 1 = " + driver.findElement(By.xpath("((.//*[contains(text(),'Booking Status')])[1]/following::tbody/tr/td[9])[1]")).getText());
	}
	
	
	//Tour 2
	public void TourName2() {		
		System.out.println("Tour " + driver.findElement(By.xpath("(.//div[@class='module_ttle'])[2]")).getText() + " is Confirmed");
	}
	
	public void Price2() {		
		System.out.println("Price for Tour 2 = " + driver.findElement(By.xpath("(.//div[@class='grandprice'])[2]")).getText());
	}
	
	public void ConfirmedStatusTour2 () {		
		System.out.println("Booking Status for Tour 2 = " + driver.findElement(By.xpath("((.//*[contains(text(),'Booking Status')])[1]/following::tbody/tr/td[9])[2]")).getText());
	}
	
	public void GrandPrice () {		
		System.out.println("Grand Price = " + driver.findElement(By.xpath("(.//*[@class='PriceBox']/div[2])[1]")).getText());
	}
	
}
