package PageObjects;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class AllDates {

	public static String CurrentDate(int i) {
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		String currendate = sdf.format(date);
		return currendate;
	}

	public static String Futurdate(int i) {
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		String futuredate = sdf.format(AllDates.getDateAfterDays(0));
		return futuredate;
	}
	
	public static String Futurdate14(int i) {
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		String futuredate = sdf.format(AllDates.getDateAfter14Days(0));
		return futuredate;
	}
	
	public static String Futurdate15(int i) {
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		String futuredate = sdf.format(AllDates.getDateAfter15Days(0));
		return futuredate;
	}
	
	public static String Futurdate20(int i) {
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		String futuredate = sdf.format(AllDates.getDateAfter20Days(0));
		return futuredate;
	}

	// After
	public static Date getDateAfterSeconds(int seconds) {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.SECOND, seconds); // +seconds
		return cal.getTime();
	}

	public static Date getDateAfterMinutes(int minutes) {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MINUTE, minutes); // +minutes
		return cal.getTime();
	}

	public static Date getDateAfterHours(int hours) {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.HOUR, hours); // +hours
		return cal.getTime();
	}

	public static Date getDateAfterDays(int days) {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 3); // +days
		return cal.getTime();
	}
	
	public static Date getDateAfter14Days(int days) {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 14); // +days
		return cal.getTime();
	}
	
	public static Date getDateAfter15Days(int days) {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 15); // +days
		return cal.getTime();
	}
	
	public static Date getDateAfter20Days(int days) {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 20); // +days
		return cal.getTime();
	}
	
	public static Date getDateAfter5Months(int months) {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MONTH, 8); // +months
		Date datetime = cal.getTime();
		return datetime;
	}

	public static Date getDateAfter8Months(int months) {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MONTH, 8); // +months
		Date datetime = cal.getTime();
		return datetime;
	}

	public static Date getDateAfterYears(int years) {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.YEAR, years); // +years
		return cal.getTime();
	}
	
	public static String formattedDateafter5months(int i) {
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		String formattedDateafter5months = sdf.format(getDateAfter5Months(0));
		return formattedDateafter5months;
	}

	public static String formattedDateafter8months(int i) {
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		String formattedDateafter8months = sdf.format(getDateAfter8Months(0));
		return formattedDateafter8months;
	}

	// Before
	public static Date getDateBeforeSeconds(int seconds) {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.SECOND, -seconds); // -seconds
		return cal.getTime();
	}

	public static Date getDateBeforeMinutes(int minutes) {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MINUTE, -minutes); // -minutes
		return cal.getTime();
	}

	public static Date getDateBeforeHours(int hours) {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.HOUR, -hours); // -hours
		return cal.getTime();
	}

	public static Date getDateBeforeDays(int days) {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -days); // -days
		return cal.getTime();
	}

	public static Date getDateBeforeMonths(int months) {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MONTH, -months); // -months
		return cal.getTime();
	}

	public static Date getDateBeforeYears(int years) {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.YEAR, -years); // -years
		return cal.getTime();
	}

}
