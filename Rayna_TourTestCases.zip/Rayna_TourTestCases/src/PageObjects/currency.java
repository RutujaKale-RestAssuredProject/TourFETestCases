package PageObjects;

import org.openqa.selenium.WebDriver;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

public class currency {
	
	WebDriver driver;
	
	By Currency = By.xpath(".//*[@id='sysCurr']");
	By AED = By.xpath(".//*[@id='sysCurr']/following::ul[@class='dropdown-content']/li/a[@title='AED']");

	public currency(WebDriver d) {
		driver =d;
	}
	
	public void Currency () {
		driver.findElement(Currency).click();
	}

	public void ClickAED () { 
		driver.findElement(AED).click();
	}

}
