package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Menus {
	
	WebDriver driver;
	
	By CreditLimit = By.xpath(".//li[@id='agtCreditLimit']");
    By AvailableLimit = By.xpath("(.//*[contains(text(),'Available Limit ')]/following-sibling::span/small)[2]");
	public By PaybyCreditLimit = By.xpath(".//*[contains(text(),'Pay By Credit Limit')]");
	By ConfirmBooking = By.xpath(".//div[@class='select_bx']/a[contains(text(),'I agree to Confirm my Booking')]");
	
	
	public Menus (WebDriver d) {
		driver =d;
	}
	
	public void AvailableCrediTLimit () {		
        driver.findElement(CreditLimit).click();
		System.out.println("Credit Limit Before Payment = " + driver.findElement(AvailableLimit).getText());
	}
	
	public void ConfirmBooking () {		
        driver.findElement(ConfirmBooking).click();
	}
	
	public void AddToCart () {		
		driver.findElement(By.id("addToCartDetails")).click();
	}
	

	
	
	

}
