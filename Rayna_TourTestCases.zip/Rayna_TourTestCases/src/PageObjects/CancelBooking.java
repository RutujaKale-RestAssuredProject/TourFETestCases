package PageObjects;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.apache.maven.shared.utils.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CancelBooking {

	WebDriver driver;

	public CancelBooking(WebDriver d) {
		driver =d;
	}

	public void CancelBooking1 () throws InterruptedException {
		driver.findElement(By.xpath("(.//*[contains(text(),'Cancel Booking')])[1]")).click();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		
		WebDriverWait wait = new WebDriverWait(driver, 10);
		WebElement TourCancelPage = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(".//h5[contains(text(),'Tour Cancellation')]")));

		// Verify the customer details
		System.out.println(driver.findElement(By.xpath(".//h5[contains(text(),'Tour Cancellation')]")).getText());
		System.out.println(
				"Passenger Name = " + driver.findElement(By.xpath(".//*[contains(text(),'Name : ')]")).getText());
		System.out.println("Passenger Email ID = "
				+ driver.findElement(By.xpath(".//*[contains(text(),'Email : ')]")).getText());
		System.out.println("Passenger Mobile number = "
				+ driver.findElement(By.xpath(".//*[contains(text(),'Call : ')]")).getText());

		// Verify the Tour Name
		System.out.println("Tour Name = " + driver
				.findElement(By.xpath(".//div[@class='tblactivityname']/span[@class='ng-binding']")).getText());

		// Verify amount
		System.out.println("Tour Amount Details are as below : ");
		System.out.println("Total Tour Amount = " + driver.findElement(By.xpath(
				".//li/p[contains(text(),'Total Amount :')]/following-sibling::div/span[@class='ng-binding']"))
		.getText());
		System.out.println("Total Amount Received = " + driver.findElement(By.xpath(
				".//ul[@class='hide']/li/p[contains(text(),'Total Amount Received :')]/following-sibling::div/span[@class='ng-binding']"))
		.getText());
		System.out.println("Cancellation Charges = " + driver.findElement(By.xpath(
				".//li/p[contains(text(),'Cancellation Charges :')]/following-sibling::div/span[@class='ng-binding']"))
		.getText());
		System.out.println("Refundable Amount = " + driver.findElement(By.xpath(
				".//li/p[contains(text(),'Refundable Charges :')]/following-sibling::div/span[@class='ng-binding']"))
		.getText());
		
		// Write the reason
		driver.findElement(By.id("txtReason")).sendKeys("Testing for cancellation of Booking");
		driver.findElement(By.xpath(".//*[contains(text(),'Cancel Booking')]")).click();
		driver.findElement(By.xpath(".//*[contains(text(),'Yes')]")).click();

		System.out.println(("Tour Booking Cancelled Successfully..!!!"));

	}
	
	public void CancelBooking2 () throws InterruptedException {
		driver.findElement(By.xpath("(.//*[contains(text(),'Cancel Booking')])[2]")).click();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		
		WebDriverWait wait = new WebDriverWait(driver, 10);
		WebElement TourCancelPage = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(".//h5[contains(text(),'Tour Cancellation')]")));

		// Verify the customer details
		System.out.println(driver.findElement(By.xpath(".//h5[contains(text(),'Tour Cancellation')]")).getText());
		System.out.println(
				"Passenger Name = " + driver.findElement(By.xpath(".//*[contains(text(),'Name : ')]")).getText());
		System.out.println("Passenger Email ID = "
				+ driver.findElement(By.xpath(".//*[contains(text(),'Email : ')]")).getText());
		System.out.println("Passenger Mobile number = "
				+ driver.findElement(By.xpath(".//*[contains(text(),'Call : ')]")).getText());

		// Verify the Tour Name
		System.out.println("Tour Name = " + driver
				.findElement(By.xpath(".//div[@class='tblactivityname']/span[@class='ng-binding']")).getText());

		// Verify amount
		System.out.println("Tour Amount Details are as below : ");
		System.out.println("Total Tour Amount = " + driver.findElement(By.xpath(
				".//li/p[contains(text(),'Total Amount :')]/following-sibling::div/span[@class='ng-binding']"))
		.getText());
		System.out.println("Total Amount Received = " + driver.findElement(By.xpath(
				".//ul[@class='hide']/li/p[contains(text(),'Total Amount Received :')]/following-sibling::div/span[@class='ng-binding']"))
		.getText());
		System.out.println("Cancellation Charges = " + driver.findElement(By.xpath(
				".//li/p[contains(text(),'Cancellation Charges :')]/following-sibling::div/span[@class='ng-binding']"))
		.getText());
		System.out.println("Refundable Amount = " + driver.findElement(By.xpath(
				".//li/p[contains(text(),'Refundable Charges :')]/following-sibling::div/span[@class='ng-binding']"))
		.getText());
		
		// Write the reason
		driver.findElement(By.id("txtReason")).sendKeys("Testing for cancellation of Booking");
		driver.findElement(By.xpath(".//*[contains(text(),'Cancel Booking')]")).click();
		driver.findElement(By.xpath(".//*[contains(text(),'Yes')]")).click();

		System.out.println(("Tour Booking Cancelled Successfully..!!!"));

	}
}
