package Tour_Bookings;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.apache.maven.shared.utils.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import com.excel.lib.util.Xls_Reader;

import PageObjects.AllDates;

public class TC007_NonRefundable_VoucherBooking {

	public static void main(String[] args) throws Exception {

		NonRefundable_VoucherBooking();
	}

	@Test(priority = 0)
	public static void NonRefundable_VoucherBooking() throws InterruptedException, Exception {
		        //Login
				System.setProperty("webdriver.chrome.driver", "C:\\Users\\Techno\\Desktop\\Automation\\Drivers\\Chrome\\chromedriver.exe");
				WebDriver driver = new ChromeDriver();
				driver.get("https://bookdubaipackage.com/");
				driver.manage().window().maximize();
				driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
						
				//Valid Login
				WebElement Agent = driver.findElement(By.id("txtAgentcode"));
				WebElement userName = driver.findElement(By.id("txtUsername"));
				WebElement pwd = driver.findElement(By.id("txtPassword"));	

				Xls_Reader reader = new Xls_Reader("./src/ExcelResults/SampleExcel.xlsx");
				String sheetName = "login";

				int rowCount = reader.getRowCount(sheetName);

				for(int rowNum=2; rowNum<=rowCount; rowNum++){
					String AgentCode = reader.getCellData(sheetName, "Agent", rowNum);
					String loginId = reader.getCellData(sheetName, "username", rowNum);
					String passsword = reader.getCellData(sheetName, "password", rowNum);

					System.out.println(AgentCode + " " + loginId + " " + passsword);

					Agent.clear();
					Agent.sendKeys(AgentCode);

					userName.clear();
					userName.sendKeys(loginId);

					pwd.clear();
					pwd.sendKeys(passsword);
					driver.findElement(By.id("btnLogin")).click(); 
					Thread.sleep(10000);   	  	
				
		// Filter for Tour
		driver.findElement(By.id("txtCityNameTour")).clear(); // Enter City or Destination name
		driver.findElement(By.id("txtCityNameTour")).sendKeys("Dubai");

		// Get Screenshot
		File Homepage = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(Homepage, new File("C:/TC007_NonRefundable_VoucherBooking/Homepage.jpg"));
		Thread.sleep(5000);

		// Change the currency to AED
		driver.findElement(By.xpath(".//*[@id='sysCurr']")).click();
		driver.findElement(By.xpath(".//ul[@class='dropdown-content']/li/a[@title='AED']")).click();
		System.out.println("AED currency is selected!");
		Thread.sleep(5000);

		// Click on Search button
		driver.findElement(By.id("btnTourSearch")).click();
		Thread.sleep(5000);

		// Select Tour
		driver.findElement(By.id("toursearchtext")).sendKeys("test");
		WebElement Tour_Name = driver.findElement(By.xpath(".//*[contains(text(),'TEST TOUR')]"));
		Tour_Name.click();
		System.out.println("TEST TOUR is clicked!");
		Thread.sleep(5000);

		// Switch to new window and verify the title
		for (String winHandle : driver.getWindowHandles()) {
			driver.switchTo().window(winHandle);
		}
		Thread.sleep(5000);

		// Scroll Down
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,-2000)", "");
		Thread.sleep(5000);

		// Select Transfer Type
		driver.findElement(By.xpath(".//*[@class='trnsfroptions']")).click();
		driver.findElement(By.xpath(".//*[@class='trnsfroptions']/div/select/option[@value=1]")).click();
		System.out.println("Sharing option selected = Sharing Transfers");

		// Enter the current date
		driver.findElement(By.xpath("(.//*[@class='datepickTD'])[1]/div/div/input")).clear();
		driver.findElement(By.xpath("(.//*[@class='datepickTD'])[1]/div/div/input")).sendKeys(AllDates.Futurdate(0));
		System.out.println("Date Entered = " + AllDates.Futurdate(0));

		// Get Screenshot
		File TourDetails = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(TourDetails, new File("C:/TC007_NonRefundable_VoucherBooking/TourDetails.jpg"));

		System.out.println("Tour Details Fetched for = "
				+ driver.findElement(By.xpath(".//div[@class='ProductNameReviews']/h1[contains(text(),'TEST TOUR')]"))
						.getText());
		Thread.sleep(5000);

		// Validations on Adult and Child
		driver.findElement(By.xpath("(.//*[@class='paxTD'])[1]")).isEnabled(); // Able to click, should show true
		driver.findElement(By.xpath("(.//*[@class='paxTD'])[2]")).isEnabled(); // Not able to click, should show true
		driver.findElement(By.xpath("(.//*[@class='paxTD'])[3]")).isEnabled(); // Not able to click, should show true
		driver.findElement(By.id("addToCartDetails")).click(); // click on Add To Cart button
		Thread.sleep(5000);

		// Get Screenshot
		File PassengerDetails = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(PassengerDetails, new File("C:/TC007_NonRefundable_VoucherBooking/PassengerDetails.jpg"));

		// Tour Name
		System.out.println("Tour Option selected = "
				+ driver.findElement(By.xpath("(.//*[contains(text(),'Tour Option')]/following::div)[1]")).getText());
		Thread.sleep(5000);

		// Transfer Type
		System.out.println("Transfer Type = " + driver
				.findElement(By.xpath(".//li/div[contains(text(),'Transfer Type')]/following-sibling::div")).getText());

		// Confirm Booking Date
		System.out.println("Booking Date = "
				+ driver.findElement(By.xpath(".//li/div[contains(text(),'Date')]/following-sibling::div")).getText());

		// Confirm Booking Time
		System.out.println("Booking Time = "
				+ driver.findElement(By.xpath(".//li/div[contains(text(),'Time')]/following-sibling::div")).getText());

		// PAX
		System.out.println("PAX = "
				+ driver.findElement(By.xpath(".//li/div[contains(text(),'Pax')]/following-sibling::div")).getText());

		// Total Amount for Tour1
		System.out.println("Total Amount for Tour option 1 = " + driver
				.findElement(By.xpath(".//*[contains(text(),'Total')]/following-sibling::div[@class='lblValuedark']"))
				.getText());

		// Confirm Final Payment
		System.out.println("Final Payment to be done for all tours = "
				+ driver.findElement(By.xpath(".//*[contains(text(),'Final Payment')]/following-sibling::p/span[2]"))
						.getText());

		// Enter Passenger Details
		driver.findElement(By.id("txtFirstNameNew")).sendKeys("Sujit");
		System.out.println("First Name is given");
		driver.findElement(By.id("txtLastNameNew")).sendKeys("Patil");
		System.out.println("Last Name is given");
		driver.findElement(By.xpath("(.//*[@class='select_bx'])[7]/input")).sendKeys("abcabc123456ghsf");
		System.out.println("Agent Reference Number is given");
		driver.findElement(By.xpath("(.//*[@class='select_bx'])[9]/input")).sendKeys("DAFZA,Dubai");
		System.out.println("Pickup Location is given"); // As sharing transfer type is given

		// Get Screenshot
		File PassengerInfo = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(PassengerInfo, new File("C:/TC007_NonRefundable_VoucherBooking/PassengerInfo.jpg"));

		// Email ID and Phone Number
		System.out.println(driver.findElement(By.id("txtEmail")).getText());
		System.out.println(driver.findElement(By.id("txtPhNo")).getText());

		// Payment Options
		driver.findElement(By.id("CreditLimit_licred")).click(); // Radio button for Credit Limit for payment is
																	// selected
		driver.findElement(By.className("checkmark")).click(); // Accept the Terms & Conditions

		// Get Screenshot
		File PaymentOption = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(PaymentOption, new File("C:/TC007_NonRefundable_VoucherBooking/PaymentOption.jpg"));

		// Check the Credit Limit Before Payment
		driver.findElement(By.xpath(".//li[@class='dropdown ']/a[contains(text(),'Credit Limit')]")).click();
		System.out.println("Credit Limit Before Payment = " + driver
				.findElement(By.xpath("(.//*[contains(text(),'Available Limit ')]/following-sibling::span/small)[2]"))
				.getText());
		Thread.sleep(5000);

		// Get Screenshot
		File CreditLimitBeforePayment = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(CreditLimitBeforePayment,
				new File("C:/TC007_NonRefundable_VoucherBooking/CreditLimitBeforePayment.jpg"));

		// Pay on Pay By Credit Limit
		driver.findElement(By.xpath(".//*[contains(text(),'Pay By Credit Limit')]")).click();
		Thread.sleep(5000);

		// Yes
		System.out.println(driver.findElement(By.xpath("(.//*[@class='modal-title'])[3]")).getText());
		driver.findElement(By.xpath("(.//*[@class='YN-btns'])[1]/a")).click();
		Thread.sleep(10000);

		// Get Screenshot
		File TourDetailsBeforePayment = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(TourDetailsBeforePayment,
				new File("C:/TC007_NonRefundable_VoucherBooking/TourDetailsBeforePayment.jpg"));

		// Tour Name and Price
		System.out.println("Tour Name before Payment =" + driver
				.findElement(By.xpath(".//div[@class='module_ttle']/span[contains(text(),'TEST TOUR')]")).getText());
		WebElement Price = driver.findElement(By.xpath(".//*[contains(text(),'Grand Total')]/following-sibling::span"));
		String PriceText = Price.getText();
		System.out.println("Grand Price before Payment =" + PriceText);

		// Click on Voucher Booking option
		driver.findElement(By.xpath(".//*[contains(text(),'Voucher Booking')]")).click();
		Thread.sleep(5000);

		// Issue Voucher
		driver.findElement(By.xpath(".//div[@class='select_bx']/following::input[@class='inputselectbox'][2]"))
				.sendKeys("123355345465");
		driver.findElement(By.xpath(
				"(.//div[@class='bottom-button']/descendant::a[contains(text(),'Issue Voucher by Credit Limit')])[3]"))
				.click();
		Thread.sleep(5000);

		// Verify the Voucher Booking Status
		System.out.println("The Booking status = "
				+ driver.findElement(By.xpath(".//span[@class='BookStatus BSvoucher'][contains(text(),'Vouchered')]"))
						.getText());

		// Get Screenshot
		File TourDetailsAfterVouchering = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(TourDetailsAfterVouchering,
				new File("C:/TC007_NonRefundable_VoucherBooking/TourDetailsAfterVouchering.jpg"));

		// Download Voucher Details
		driver.findElement(By.id("ContentPlaceHolder1_ctl00_lnkTourVoucherPdf")).click();
		System.out.println("Voucher Details downloaded successfully!");
		Thread.sleep(10000);

		// Download Invoice
		driver.findElement(By.xpath("(.//*[contains(text(),'Download  invoice')])[2]")).click();
		System.out.println("Invoice is downloaded successfully!");
		Thread.sleep(10000);

		// Download Ticket
		driver.findElement(By.xpath(".//*[contains(text(),'Download Ticket')]")).click();
		System.out.println("Ticket is downloaded successfully!");
		Thread.sleep(10000);

		//View Voucher
		driver.findElement(By.xpath(".//*[contains(text(),'View Voucher')]")).click();
		System.out.println("Voucher is opened successfully!");
		Thread.sleep(10000);

		// Details verify from Voucher Page
		driver.findElement(By.xpath("((.//*[@class='logopart'])[1]/div/div/div/img)[1]")).isDisplayed();
		System.out.println("Rayna logo on top left corner is displayed on Voucher details page!");

		System.out.println(
				"Reference Number = " + driver.findElement(By.xpath("(.//*[@class='ref-rt']/h3/span)[1]")).getText());
		System.out.println("PIN = " + driver.findElement(By.xpath("(.//*[@class='ref-rt']/h3/span)[3]")).getText());

		driver.findElement(By.xpath(".//*[@class='ref-rt']/following::div/img")).isDisplayed();
		System.out.println("Bar Code is displayed on Voucher details page!");

		// Get Screenshot
		File VoucherDetailsPage1 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(VoucherDetailsPage1,
				new File("C:/TC007_NonRefundable_VoucherBooking/VoucherDetailsPage1.jpg"));

		System.out.println("Booking Date = " + driver
				.findElement(By.xpath("((.//*[contains(text(),'Booking Date')])[1]/following::td/span)[1]")).getText());
		System.out.println("Tour Date = " + driver
				.findElement(By.xpath("((.//*[contains(text(),'Tour Date')])[1]/following::td/span)[1]")).getText());
		System.out.println("Tour Name = " + driver
				.findElement(By.xpath("((.//*[contains(text(),'Tour Details')])[1]/following::td/span)[2]")).getText());
		System.out.println("Transfer Type = " + driver
				.findElement(By.xpath("(.//*[contains(text(),'Transfer Type')])[2]/following::tbody/tr/td")).getText());
		System.out.println("Guest Name = " + driver
				.findElement(By.xpath("((.//*[contains(text(),'Name')])[2]/following::tbody/tr/td)[1]")).getText());
		System.out.println("Guest Email ID = " + driver
				.findElement(By.xpath("((.//*[contains(text(),'Name')])[2]/following::tbody/tr/td)[2]")).getText());
		System.out.println("Guest Mobile Number = " + driver
				.findElement(By.xpath("((.//*[contains(text(),'Name')])[2]/following::tbody/tr/td)[3]")).getText());

		// Cancel Booking not available
		if (driver.findElement(By.xpath(".//*[contains(text(),'Cancel Booking')]")).isEnabled())
			;
		{
			System.out.println("Booking can be Cancelled as the Cancel Booking Button is present");
		}
		{
			System.out.println("Booking can't be Cancelled as the Cancel Booking Button is not present");

		}
		Thread.sleep(5000);

		// Get Screenshot
		File VoucherDetailsPage2 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(VoucherDetailsPage2,
				new File("C:/TC007_NonRefundable_VoucherBooking/VoucherDetailsPage2.jpg"));

		driver.findElement(By.xpath("(.//*[@type='button'])[13]")).click();
		Thread.sleep(10000);

		System.out.println("The booking is Vouchered with price = " + PriceText);

		// Check the Credit Limit After Payment
		driver.findElement(By.xpath(".//*[@id='agtCreditLimit']")).click();
		Thread.sleep(10000);
		System.out.println("Credit Limit after Payment = " + driver
				.findElement(By.xpath("(.//*[contains(text(),'Available Limit ')]/following-sibling::span/small)[2]"))
				.getText());
		Thread.sleep(5000);

		// Get Screenshot
		File CreditLimitAfterPayment = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(CreditLimitAfterPayment,
				new File("C:/TC007_NonRefundable_VoucherBooking/CreditLimitAfterPayment.jpg"));

		// Sign out
		driver.findElement(By.xpath("//a[@href='/Signout.aspx']")).click();
		Thread.sleep(5000);

		// Get Screenshot
		File SignOutPage = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(SignOutPage, new File("C:/TC007_NonRefundable_VoucherBooking/SignOutPage.jpg"));
		System.out.println("Test Script passed successfully!");

		driver.close();
		driver.quit();

	}
  }
}
