package Tour_Bookings;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestingPurpose {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Techno\\Desktop\\Automation\\Drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);		
		driver.get("https://www.saucedemo.com/");
		
		Login(driver);
		AddToCart(driver);

		/* driver.findElement(By.cssSelector(".shopping_cart_badge")).click(); */
		
	}
	
	public static void Login(WebDriver driver) {		
		driver.findElement(By.id("user-name")).sendKeys("standard_user");
		driver.findElement(By.id("password")).sendKeys("secret_sauce");
		driver.findElement(By.cssSelector("input#login-button")).click();;
	}

	public static void AddToCart(WebDriver driver) {		
		for(int i = 1 ; i<=6 ; i++){
			  driver.findElement(By.xpath("(.//*[contains(@class,'btn_inventory')])["+i+"]")).click();
		}
	}

}
