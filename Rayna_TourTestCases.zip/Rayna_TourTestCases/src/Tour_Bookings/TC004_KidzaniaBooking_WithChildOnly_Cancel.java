package Tour_Bookings;

import java.io.File;
import java.util.concurrent.TimeUnit;
import org.apache.maven.shared.utils.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.testng.annotations.Test;
import com.excel.lib.util.Xls_Reader;
import PageObjects.AllDates;
import PageObjects.CancelBooking;
import PageObjects.ConfirmedTravelCart;
import PageObjects.PassengerDetailsPage;
import PageObjects.SalesInvoice;
import PageObjects.ViewInvoice;
import PageObjects.VoucheredTravelCart;

import org.openqa.selenium.support.ui.WebDriverWait;

public class TC004_KidzaniaBooking_WithChildOnly_Cancel {

	public static void main(String[] args) throws Exception {

		KidzaniaBooking_WithChildOnly_Cancel();
	}		  

	@Test(priority=0)
	public static void KidzaniaBooking_WithChildOnly_Cancel() throws InterruptedException, Exception {		
		//Login
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Techno\\Desktop\\Automation\\Drivers\\Chrome\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://bookdubaipackage.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 10);
		
		PassengerDetailsPage PassengerDT = new PassengerDetailsPage (driver);
		VoucheredTravelCart VCart = new VoucheredTravelCart(driver);
		SalesInvoice InvoiceDetails = new SalesInvoice(driver);
		CancelBooking Cancel = new CancelBooking (driver);
		
		//Valid Login
		WebElement Agent = driver.findElement(By.id("txtAgentcode"));
		WebElement userName = driver.findElement(By.id("txtUsername"));
		WebElement pwd = driver.findElement(By.id("txtPassword"));	

		Xls_Reader reader = new Xls_Reader("./src/ExcelResults/SampleExcel.xlsx");
		String sheetName = "login";

		int rowCount = reader.getRowCount(sheetName);

		for(int rowNum=2; rowNum<=rowCount; rowNum++){
			String AgentCode = reader.getCellData(sheetName, "Agent", rowNum);
			String loginId = reader.getCellData(sheetName, "username", rowNum);
			String passsword = reader.getCellData(sheetName, "password", rowNum);

			System.out.println(AgentCode + " " + loginId + " " + passsword);

			Agent.clear();
			Agent.sendKeys(AgentCode);

			userName.clear();
			userName.sendKeys(loginId);

			pwd.clear();
			pwd.sendKeys(passsword);
			driver.findElement(By.id("btnLogin")).click(); 
			Thread.sleep(10000);  	  	

			//Filter for Tour
			driver.findElement(By.id("txtCityNameTour")).clear(); //Enter City or Destination name
			driver.findElement(By.id("txtCityNameTour")).sendKeys("Dubai");

			//Get Screenshot
			File Homepage = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(Homepage, new File("C:/TC004_KidzaniaWithChildsOnly_Booking_Cancel/Homepage.jpg"));
			Thread.sleep(5000);

			//Change the currency to AED
			driver.findElement(By.xpath(".//*[@id='sysCurr']")).click();
			driver.findElement(By.xpath(".//ul[@class='dropdown-content']/li/a[@title='AED']")).click();
			Thread.sleep(5000);

			//Click on Search button
			driver.findElement(By.id("btnTourSearch")).click();
			Thread.sleep(5000);

			//Select Tour
			WebElement Tour_Name = driver.findElement(By.xpath(".//*[contains(text(),'Dubai Mall Kidzania')]"));
			Tour_Name.click();
			System.out.println("Dubai Mall Kidzania is clicked!");
			Thread.sleep(5000);

			//Switch to new window and verify the title
			for(String winHandle : driver.getWindowHandles()){
				driver.switchTo().window(winHandle);
			}
			Thread.sleep(5000);

			//Enter the current date
			driver.findElement(By.xpath("(.//*[@class='datepickTD'])[1]/div/div/input")).clear();
	     	driver.findElement(By.xpath("(.//*[@class='datepickTD'])[1]/div/div/input")).sendKeys(AllDates.Futurdate14(0));
	     	System.out.println("Current Date = " + AllDates.Futurdate14(0) + "is entered");

			//Select 0 Adults
			driver.findElement(By.xpath("(.//*[@class='select_bx'])[2]")).click();
			driver.findElement(By.xpath("(.//*[@class='select_bx'])[2]/select/option[@value='0']")).click();
			System.out.println("0 Adults selected");

			//Select 2 Children
			driver.findElement(By.xpath("(.//*[@class='select_bx'])[3]")).click();
			driver.findElement(By.xpath("(.//*[@class='select_bx'])[3]/select/option[@value='2']")).click();
			System.out.println("2 Children selected");
			
			//Get Screenshot
			File TourDetails = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(TourDetails, new File("C:/TC004_KidzaniaWithChildsOnly_Booking_Cancel/TourDetails.jpg"));

			//Get the Total Price before adding to cart
			String PricefromTourDetails = driver.findElement(By.xpath(".//span[@class='OrigionalPrice']")).getText();
			System.out.println("TourPrice = " + PricefromTourDetails);

			System.out.println("Tour Details Fetched for = " + driver.findElement(By.xpath(".//div[@class='ProductNameReviews']/h1[contains(text(),'Dubai Mall Kidzania')]")).getText());
			Thread.sleep(5000);

			driver.findElement(By.id("addToCartDetails")).click(); //click on Add To Cart button	
			Thread.sleep(5000);

			//Get Screenshot
			File PassengerDetails = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(PassengerDetails, new File("C:/TC002_VoucherBooking_Cancel/PassengerDetails.jpg")); 	
			
			//Passenger Details Page
			PassengerDT.TourName1();
			PassengerDT.TransferType1();
			PassengerDT.BookingDate1();
			PassengerDT.BookingTime1();
			PassengerDT.PAX1();
			PassengerDT.CancellationDate1();
			PassengerDT.AmountTour1();
			PassengerDT.FinalPayment();		
			//Get Screenshot
			File PassengerInfo1 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(PassengerInfo1, new File("C:/TC002_VoucherBooking_Cancel/PassengerInfo1.jpg")); 
			PassengerDT.PassengerInfo();		
			//Get Screenshot
			File PassengerInfo2 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(PassengerInfo2, new File("C:/TC002_VoucherBooking_Cancel/PassengerInfo2.jpg")); 

			//Payment Options
			driver.findElement(By.id("CreditLimit_licred")).click(); //Radio button for Credit Limit for payment is selected
			driver.findElement(By.className("checkmark")).click(); //Accept the Terms & Conditions

			//Get Screenshot
			File PaymentOption = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(PaymentOption, new File("C:/TC004_KidzaniaWithChildsOnly_Booking_Cancel/PaymentOption.jpg")); 

			//Check the Credit Limit Before Payment
			driver.findElement(By.xpath(".//li[@class='dropdown ']/a[contains(text(),'Credit Limit')]")).click();
			System.out.println("Credit Limit Before Payment = " + driver.findElement(By.xpath("(.//*[contains(text(),'Available Limit ')]/following-sibling::span/small)[2]")).getText());

			//Get Screenshot
			File CreditLimitBeforePayment = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(CreditLimitBeforePayment, new File("C:/TC004_KidzaniaWithChildsOnly_Booking_Cancel/CreditLimitBeforePayment.jpg")); 

			//Pay on Pay By Credit Limit
			driver.findElement(By.xpath(".//*[contains(text(),'Pay By Credit Limit')]")).click();
			Thread.sleep(5000);  

			//Enter Reference Number and click on Voucher Booking
			driver.findElement(By.id("txtCommonAgentRefNo")).sendKeys("TestingPurpose");
			//Get Screenshot
			File ReferenceNumber = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(ReferenceNumber, new File("C:/TC004_KidzaniaWithChildsOnly_Booking_Cancel/ReferenceNumber.jpg")); 
			driver.findElement(By.xpath(".//*[contains(text(),'I agree to Voucher my Booking')]")).click();
			new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(By.xpath(".//div[@class='Notificationtext']/following-sibling::div/a"))).click();
			Thread.sleep(5000);

			String TourOption = driver.findElement(By.xpath(".//div[@class='module_ttle']")).getText();
			System.out.println(TourOption);
			String Price = driver.findElement(By.xpath(".//div[@class='grandprice']")).getText();
			System.out.println("The booking is Vouchered for Dubai Mall Kidzania with price = " + " " + Price);

			//Get Screenshot
			File BookingVouchered = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(BookingVouchered, new File("C:/TC004_KidzaniaWithChildsOnly_Booking_Cancel/BookingVouchered.jpg"));

			// Download Invoice
	        VCart.DonwloadInvoiceButton();
	        //Click on View Invoice
	        VCart.ViewInvoice();
	        
	        // Details verify from Invoice Page
	        WebElement Logo = wait.until(
	        		ExpectedConditions.visibilityOfElementLocated(By.xpath("(.//*[@class='logopart']/div)[3]")));
	        Logo.isDisplayed();
	        InvoiceDetails.InvoiceLogo();
	        InvoiceDetails.ReferenceDetails();
	        
	        // Get Screenshot
	        File InvoiceDetailsPage1 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	        FileUtils.copyFile(InvoiceDetailsPage1,
	        		new File("C:/TC011_DubaiFountainShow_VoucherBooking_CheckSeats/InvoiceDetailsPage1.jpg"));

	        InvoiceDetails.ServiceType();
	        InvoiceDetails.TourDetails();

	        // Get Screenshot
	        File InvoiceDetailsPage2 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	        FileUtils.copyFile(InvoiceDetailsPage2,
	        		new File("C:/TC011_DubaiFountainShow_VoucherBooking_CheckSeats/InvoiceDetailsPage2.jpg"));		

	        //Cancellation charges on invoice
	        InvoiceDetails.CancellationChargeForTour1();   
	        
	        File InvoiceDetailsPage3 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	        FileUtils.copyFile(InvoiceDetailsPage3,
	        		new File("C:/TC011_DubaiFountainShow_VoucherBooking_CheckSeats/InvoiceDetailsPage3.jpg"));

	        InvoiceDetails.Close();
	        Thread.sleep(5000);
	       
			// Click on Cancel Booking
			Cancel.CancelBooking1();
			Thread.sleep(15000);

			// Sign out
			System.out.println("Test Script passed successfully!");
			Thread.sleep(5000);

			driver.close();
		}		
	}
}
