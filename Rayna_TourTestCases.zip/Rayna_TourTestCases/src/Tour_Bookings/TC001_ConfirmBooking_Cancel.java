package Tour_Bookings;

import java.io.File;
import java.util.Currency;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.apache.maven.shared.utils.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.testng.annotations.Test;
import com.excel.lib.util.Xls_Reader;

import ExcelResults.WriteExcel;

import org.openqa.selenium.support.ui.WebDriverWait;
import static org.testng.Assert.assertTrue;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;

import PageObjects.AllDates;
import PageObjects.AllTours;
import PageObjects.CancelBooking;
import PageObjects.ConfirmedTravelCart;
import PageObjects.Homepage;
import PageObjects.LoginPage;
import PageObjects.Menus;
import PageObjects.PassengerDetailsPage;
import PageObjects.ViewInvoice;
import PageObjects.currency;

public class TC001_ConfirmBooking_Cancel {

	public static void main(String[] args) throws Exception {

		ConfirmBooking_Cancel();
	}

	@Test(priority = 0)
	public static void ConfirmBooking_Cancel() throws InterruptedException, Exception {
		// Login
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Techno\\Desktop\\Automation\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		//Calling Page Objects from Different Classes
		currency CU = new currency (driver);
		AllTours Tour = new AllTours (driver);
		PassengerDetailsPage PassengerDT = new PassengerDetailsPage (driver);
		Menus Menu = new Menus (driver);
		CancelBooking Cancel = new CancelBooking (driver);
		Homepage HomePage = new Homepage(driver);
		ConfirmedTravelCart CCart = new ConfirmedTravelCart(driver);
		ViewInvoice InvoiceDetails = new ViewInvoice(driver);
		//For writing the results in Excel sheet
		WriteExcel excel = new WriteExcel();

		driver.get("https://bookdubaipackage.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		
		
//		System.out.println(driver.findElement(By.cssSelector(".corona-msg")).getText().split(" ")[2]);

		// Valid Login
		WebElement Agent = driver.findElement(By.id("txtAgentcode"));
		WebElement userName = driver.findElement(By.id("txtUsername"));
		WebElement pwd = driver.findElement(By.id("txtPassword"));	

		Xls_Reader reader = new Xls_Reader("./src/ExcelResults/SampleExcel.xlsx");
		String sheetName = "login";

		int rowCount = reader.getRowCount(sheetName);

		for(int rowNum=2; rowNum<=rowCount; rowNum++){
			String AgentCode = reader.getCellData(sheetName, "Agent", rowNum);
			String loginId = reader.getCellData(sheetName, "username", rowNum);
			String passsword = reader.getCellData(sheetName, "password", rowNum);

			System.out.println(AgentCode + " " + loginId + " " + passsword);

			Agent.clear();
			Agent.sendKeys(AgentCode);

			userName.clear();
			userName.sendKeys(loginId);

			pwd.clear();
			pwd.sendKeys(passsword);
			driver.findElement(By.id("btnLogin")).click(); 
			Thread.sleep(10000);
				
//		Actions actions = new Actions(driver);
//		WebElement elementLocator = driver.findElement(By.xpath(".//a[@href='/covid-19-uae-guidelines']"));
//		actions.contextClick(elementLocator).build().perform();
//		actions.sendKeys(Keys.ARROW_DOWN).click().build().perform();
//		Thread.sleep(10000);
		
		/*
		 * driver.findElement(By.xpath(".//a[@href='/covid-19-uae-guidelines']")).
		 * sendKeys(Keys.CONTROL,Keys.ENTER);
		 * 
		 * //Get handles of the windows String mainWindowHandle =
		 * driver.getWindowHandle(); Set<String> allWindowHandles =
		 * driver.getWindowHandles(); Iterator<String> iterator =
		 * allWindowHandles.iterator();
		 * 
		 * String parentId = iterator.next();
		 * 
		 * String childId = iterator.next();
		 * 
		 * driver.switchTo().window(childId);
		 * 
		 * driver.switchTo().window(parentId);
		 */

		WebDriverWait wait = new WebDriverWait(driver, 10);
		WebElement City = wait.until(ExpectedConditions.elementToBeClickable(By.id("txtCityNameTour")));
		City.isDisplayed();
		Thread.sleep(10000);	

        // Enter City or Destination name
		HomePage.TourCity();
		
		// Get Screenshot
		File Homepage = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(Homepage, new File("C:/TC001_ConfirmBooking_Cancel/Homepage.jpg"));
		Thread.sleep(5000);

		// Change the currency to AED
		CU.Currency();
		CU.ClickAED();
		Thread.sleep(5000);

		// Click on Search button
		HomePage.SearchButton();
		Thread.sleep(5000);

		// Select Tour from AllTours as Dhow Cruise Dinner
		Tour.DhowCruiseDinner();
		Thread.sleep(5000);

		// Switch to new window and verify the title
		for (String winHandle : driver.getWindowHandles()) {
			driver.switchTo().window(winHandle);
		}
		Thread.sleep(5000);

		// Get Screenshot
		File TourDetails = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(TourDetails, new File("C:/TC001_ConfirmBooking_Cancel/TourDetails.jpg"));

		//Tour Details
		
		String TourName = driver
				.findElement(By.xpath(
						".//div[@class='ProductNameReviews']/h1[contains(text(),'Dhow Cruise Dinner - Creek')]"))
		.getText();
		System.out.println("Tour Details Fetched for = " + TourName);
		excel.writeExcel("Sheet1", TourName, 0, 2);
		
		driver.findElement(By.xpath("(.//*[@class='datepickTD'])[1]/div/div/input")).clear();
		driver.findElement(By.xpath("(.//*[@class='datepickTD'])[1]/div/div/input")).sendKeys(AllDates.Futurdate20(0));
		System.out.println("Date Entered = " + AllDates.Futurdate20(0));
		Thread.sleep(5000);

		// click on Add To Cart button
		Menu.AddToCart();
		Thread.sleep(5000);

		// Get Screenshot
		File PassengerDetails = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(PassengerDetails, new File("C:/TC001_ConfirmBooking_Cancel/PassengerDetails.jpg"));

		//Confirm the Details from Passenger Details Page
		PassengerDT.TourName1();
		PassengerDT.TransferType1();
		PassengerDT.BookingDate1();
		PassengerDT.BookingTime1();
		PassengerDT.PAX1();
		PassengerDT.CancellationDate1();
		PassengerDT.AmountTour1();
		PassengerDT.FinalPayment();
		PassengerDT.PassengerInfo();
        
		// Get Screenshot
		File PassengerInfo = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(PassengerInfo, new File("C:/TC001_ConfirmBooking_Cancel/PassengerInfo.jpg"));

		// Payment Options
		PassengerDT.RadioButtonPayByCreditLimit(); // Radio button for Credit Limit for payment is
		PassengerDT.TermsConditions(); // Accept the Terms & Conditions

		// Get Screenshot
		File PaymentOption = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(PaymentOption, new File("C:/TC001_ConfirmBooking_Cancel/PaymentOption.jpg"));

		// Check the Credit Limit Before Payment
        Menu.AvailableCrediTLimit();
		Thread.sleep(5000);

		// Get Screenshot
		File CreditLimitBeforePayment = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(CreditLimitBeforePayment,
				new File("C:/TC001_ConfirmBooking_Cancel/CreditLimitBeforePayment.jpg"));

		// Pay on Pay By Credit Limit
		driver.findElement(Menu.PaybyCreditLimit).click();
		Thread.sleep(5000);

		// Enter Reference Number and click on Confirm Booking
	    Menu.ConfirmBooking();
		Thread.sleep(5000);

		//Travel Cart
		CCart.TourName1();
		CCart.Price1();;
		CCart.GrandPrice();

		// Get Screenshot
		File BookingConfirmed = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(BookingConfirmed, new File("C:/TC001_ConfirmBooking_Cancel/BookingConfirmed.jpg"));

		// Download Invoice
        CCart.DonwloadInvoiceButton();
        //Click on View Invoice
        CCart.ViewInvoice();
        
        // Details verify from Invoice Page
        WebElement Logo = wait.until(
        		ExpectedConditions.visibilityOfElementLocated(By.xpath("(.//*[@class='logopart']/div)[1]")));
        InvoiceDetails.InvoiceLogo();
        InvoiceDetails.ReferenceDetails();
        
        // Get Screenshot
        File InvoiceDetailsPage1 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        FileUtils.copyFile(InvoiceDetailsPage1,
        		new File("C:/TC011_DubaiFountainShow_VoucherBooking_CheckSeats/InvoiceDetailsPage1.jpg"));

        InvoiceDetails.ServiceType();
        InvoiceDetails.TourDetails();

        // Get Screenshot
        File InvoiceDetailsPage2 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        FileUtils.copyFile(InvoiceDetailsPage2,
        		new File("C:/TC011_DubaiFountainShow_VoucherBooking_CheckSeats/InvoiceDetailsPage2.jpg"));		

        //Cancellation charges on invoice
        InvoiceDetails.CancellationChargeForTour1();   
        
        File InvoiceDetailsPage3 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        FileUtils.copyFile(InvoiceDetailsPage3,
        		new File("C:/TC011_DubaiFountainShow_VoucherBooking_CheckSeats/InvoiceDetailsPage3.jpg"));

        InvoiceDetails.Close();
        Thread.sleep(5000);
        
		// Click on Cancel Booking
		Cancel.CancelBooking1();
		Thread.sleep(15000);

		// Sign out
		WebElement Signout = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@href='/Signout.aspx']")));
		Signout.click();
		System.out.println("Test Script passed successfully!");
		Thread.sleep(5000);

		driver.close();
		}
	}
}
