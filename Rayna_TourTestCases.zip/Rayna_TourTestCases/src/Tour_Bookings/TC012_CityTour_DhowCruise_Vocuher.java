package Tour_Bookings;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.apache.maven.shared.utils.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import com.excel.lib.util.Xls_Reader;

import PageObjects.AllDates;

public class TC012_CityTour_DhowCruise_Vocuher {

	public static void main(String[] args) throws Exception {
		// Login
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Techno\\Desktop\\Automation\\Drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		Login(driver);

		System.out.println(Homepage());

		driver.findElement(By.xpath(".//*[@id='sysCurr']")).click();
		driver.findElement(By.id("txtCityNameTour")).sendKeys("Dubai");

		// Get Screenshot
		File Homepage = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(Homepage, new File("C:/TC012_CityTour_DhowCruise_Vocuher/Homepage.jpg"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Thread.sleep(5000);

		// Change the currency to AED
		driver.findElement(By.xpath(".//*[@id='sysCurr']")).click();
		driver.findElement(By.xpath(".//ul[@class='dropdown-content']/li/a[@title='AED']")).click();
		System.out.println("AED currency is selected!");
		Thread.sleep(5000);

		WebDriverWait wait = new WebDriverWait(driver, 10);
		WebElement PriceLoading = wait
				.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='PriceBoxRight']")));
		PriceLoading.isDisplayed();

		// Select Tour 1
		driver.findElement(By.id("toursearchtext")).sendKeys("Tour");
		Thread.sleep(10000);
		WebElement Tour_Name = driver.findElement(By.xpath(".//*[contains(text(),'Dubai City Tour')]"));
		Tour_Name.click();
		System.out.println("Dubai City Tour is clicked!");
		Thread.sleep(5000);

		// Switch to new window and verify the title
		for (String winHandle : driver.getWindowHandles()) {
			driver.switchTo().window(winHandle);
		}
		Thread.sleep(5000);

		System.out.println("Tour Details Fetched for = "
				+ driver.findElement(By.xpath("(.//*[contains(text(),'Dubai City Tour')])[2]")).getText());
		Thread.sleep(5000);

		// Dubai City Tour Option 1
		System.out.println("Tour name 1 = "
				+ driver.findElement(By.xpath("(.//*[@class='trnsfroptions']/div/select)[1]")).getText());
		// Transfer Type - Without Transfer
		// Enter the future date after 20 Days
		driver.findElement(By.xpath("(.//*[@class='datepickTD'])[1]/div/div/input")).clear();
		driver.findElement(By.xpath("(.//*[@class='datepickTD'])[1]/div/div/input")).sendKeys(AllDates.Futurdate20(0));
		System.out.println("Date Entered = " + AllDates.Futurdate20(0));
		// Number of PAX
		// 1 adult by default selected
		// 1 Child
		driver.findElement(By.xpath("(.//*[@class='paxTD']/div/select)[2]")).click();
		driver.findElement(By.xpath("(.//*[@class='paxTD']/div/select)[2]/option[@value='1']")).click();
		// 1 Infant
		driver.findElement(By.xpath("(.//*[@class='paxTD']/div/select)[3]")).click();
		driver.findElement(By.xpath("(.//*[@class='paxTD']/div/select)[3]/option[@value='1']")).click();
		// Price calculated for tour 1
		String PriceTour1 = driver.findElement(By.xpath("((.//span[@class='OrigionalPrice'])/span[2])[2]")).getText();
		System.out.println("Price for Tour 1 = " + PriceTour1);

		// Get Screenshot
		File TourDetails1 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(TourDetails1, new File("C:/TC012_CityTour_DhowCruise_Vocuher/TourDetails1.jpg"));

		driver.findElement(By.id("addToCartDetails")).click(); // click on Add To Cart button
		Thread.sleep(15000);

		// Continue Shopping
		driver.findElement(By.id("cntshopping")).click();
		Thread.sleep(10000);

		// Search from Homepage
		driver.findElement(By.id("txtCityNameTour")).sendKeys("Dubai");
		driver.findElement(By.id("btnTourSearch")).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='PriceBoxRight']")));

		// Select Tour 2
		Thread.sleep(10000);
		driver.findElement(By.xpath(".//*[contains(text(),'Dhow Cruise Dinner - Creek')]")).click();
		System.out.println("Dhow Cruise Dinner - Creek is clicked!");
		Thread.sleep(5000);

		// Switch to new window and verify the title
		for (String winHandle : driver.getWindowHandles()) {
			driver.switchTo().window(winHandle);
		}
		Thread.sleep(5000);

		System.out.println("Tour Details Fetched for = "
				+ driver.findElement(By.xpath("(.//*[contains(text(),'Dhow Cruise Dinner - Creek')])[2]")).getText());
		Thread.sleep(5000);

		// Dhow Cruise Dinner - Creek
		System.out.println("Tour name 1 = "
				+ driver.findElement(By.xpath("(.//*[@class='trnsfroptions']/div/select)[1]")).getText());
		// Transfer Type - Without Transfer
		// Enter the future date after 20 Days
		driver.findElement(By.xpath("(.//*[@class='datepickTD'])[1]/div/div/input")).clear();
		driver.findElement(By.xpath("(.//*[@class='datepickTD'])[1]/div/div/input")).sendKeys(AllDates.Futurdate20(0));
		System.out.println("Date Entered = " + AllDates.Futurdate20(0));
		// Number of PAX
		// 1 adult by default selected
		// 1 Child
		driver.findElement(By.xpath("(.//*[@class='paxTD']/div/select)[2]")).click();
		driver.findElement(By.xpath("(.//*[@class='paxTD']/div/select)[2]/option[@value='1']")).click();
		// 1 Infant
		driver.findElement(By.xpath("(.//*[@class='paxTD']/div/select)[3]")).click();
		driver.findElement(By.xpath("(.//*[@class='paxTD']/div/select)[3]/option[@value='1']")).click();
		// Price calculated for tour 1
		System.out.println("Price for Tour 2 = "
				+ driver.findElement(By.xpath("((.//span[@class='OrigionalPrice'])/span[2])[2]")).getText());

		// Get Screenshot
		File TourDetails2 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(TourDetails2, new File("C:/TC012_CityTour_DhowCruise_Vocuher/TourDetails2.jpg"));

		driver.findElement(By.id("addToCartDetails")).click(); // click on Add To Cart button
		Thread.sleep(15000);

		WebElement NavToPassengerDetails = wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("((.//*[contains(text(),'Tour Option')])[1])/following::div[1]")));
		NavToPassengerDetails.isDisplayed();

		// Tour Name 1
		System.out.println("Tour Option selected = " + driver
				.findElement(By.xpath("((.//*[contains(text(),'Tour Option')])[1])/following::div[1]")).getText());
		Thread.sleep(5000);
		// Transfer Type
		System.out.println("Transfer Type = " + driver
				.findElement(By.xpath("(.//li/div[contains(text(),'Transfer Type')])[1]/following-sibling::div[1]"))
				.getText());
		// Confirm Booking Date
		System.out.println("Booking Date = "
				+ driver.findElement(By.xpath("(.//*[contains(text(),'Date')]/following-sibling::div)[1]")).getText());
		// Confirm Booking Time
		System.out.println("Booking Time = "
				+ driver.findElement(By.xpath("(.//*[contains(text(),'Time')]/following-sibling::div)[1]")).getText());
		// PAX
		System.out.println("PAX = "
				+ driver.findElement(By.xpath("(.//*[contains(text(),'Pax')]/following-sibling::div)[1]")).getText());
		// Total Amount for Tour1
		System.out.println("Total Amount for Tour option 1 = "
				+ driver.findElement(By.xpath("(.//*[contains(text(),'Total')]/following-sibling::div)[1]")).getText());

		// Tour Name 2
		System.out.println("Tour Option selected = " + driver
				.findElement(By.xpath("((.//*[contains(text(),'Tour Option')])[2])/following::div[1]")).getText());
		Thread.sleep(5000);
		// Transfer Type
		System.out.println("Transfer Type = " + driver
				.findElement(By.xpath("(.//li/div[contains(text(),'Transfer Type')])[2]/following-sibling::div[1]"))
				.getText());
		// Confirm Booking Date
		System.out.println("Booking Date = "
				+ driver.findElement(By.xpath("(.//*[contains(text(),'Date')]/following-sibling::div)[2]")).getText());
		// Confirm Booking Time
		System.out.println("Booking Time = "
				+ driver.findElement(By.xpath("(.//*[contains(text(),'Time')]/following-sibling::div)[2]")).getText());
		// PAX
		System.out.println("PAX = "
				+ driver.findElement(By.xpath("(.//*[contains(text(),'Pax')]/following-sibling::div)[2]")).getText());
		// Total Amount for Tour1
		System.out.println("Total Amount for Tour option 2 = "
				+ driver.findElement(By.xpath("(.//*[contains(text(),'Total')]/following-sibling::div)[2]")).getText());

		// Confirm Final Payment
		System.out.println("Final Payment to be done for all tours = " + driver
				.findElement(By.xpath(".//*[contains(text(),'Final Payment')]/following-sibling::p")).getText());

		// Enter Passenger Details
		driver.findElement(By.id("txtFirstNameNew")).sendKeys("Sujit");
		System.out.println("First Name is given");
		driver.findElement(By.id("txtLastNameNew")).sendKeys("Patil");
		System.out.println("Last Name is given");

		// Get Screenshot
		File PassengerInfo = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(PassengerInfo, new File("C:/TC012_CityTour_DhowCruise_Vocuher/PassengerInfo.jpg"));

		// Email ID and Phone Number
		System.out.println(driver.findElement(By.id("txtEmail")).getText());
		System.out.println(driver.findElement(By.id("txtPhNo")).getText());

		// Pickup location
		driver.findElement(By.xpath(
				"((.//*[contains(text(),'Dubai City Tour Morning(Diera, Bur dubai')])[1]/following::div/div/div/div/input)[1]"))
				.sendKeys("Deira,Dubai");
		Thread.sleep(10000);
		System.out.println("Pickup location entered!");

		// Payment Options
		driver.findElement(By.id("CreditLimit_licred")).click(); // Radio button for Credit Limit for payment is
		// selected
		driver.findElement(By.className("checkmark")).click(); // Accept the Terms & Conditions

		// Get Screenshot
		File PaymentOption = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(PaymentOption, new File("C:/TC012_CityTour_DhowCruise_Vocuher/PaymentOption.jpg"));

		// Check the Credit Limit Before Payment
		driver.findElement(By.xpath("(.//*[contains(text(),'Credit Limit')])[1]")).click();
		System.out.println("Credit Limit Before Payment = " + driver
				.findElement(By.xpath("(.//*[contains(text(),'Available Limit ')]/following-sibling::span/small)[2]"))
				.getText());
		Thread.sleep(5000);

		// Get Screenshot
		File CreditLimitBeforePayment = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(CreditLimitBeforePayment,
				new File("C:/TC012_CityTour_DhowCruise_Vocuher/CreditLimitBeforePayment.jpg"));

		// Pay on Pay By Credit Limit
		driver.findElement(By.xpath(".//*[contains(text(),'Pay By Credit Limit')]")).click();
		Thread.sleep(5000);

		// Get Screenshot
		File TourDetailsBeforePayment = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(TourDetailsBeforePayment,
				new File("C:/TC012_CityTour_DhowCruise_Vocuher/TourDetailsBeforePayment.jpg"));

		// Click on confirm Booking option
		driver.findElement(By.xpath(".//*[contains(text(),'I agree to Confirm my Booking')]")).click();
		Thread.sleep(5000);

		// Tour 1 Confirmation Details
		System.out.println("The booking is confirmed for"
				+ driver.findElement(By.xpath("((.//*[contains(text(),'Tour Option')])[1]/following::tbody/tr/td)[1]"))
						.getText()
				+ " with price " + driver.findElement(By.xpath("(.//*[@class='grandprice'])[1]")).getText());
		// Tour 2 Confirmation Details
		System.out.println("The booking is confirmed for"
				+ driver.findElement(By.xpath("((.//*[contains(text(),'Tour Option')])[2]/following::tbody/tr/td)[1]"))
						.getText()
				+ " with price " + driver.findElement(By.xpath("(.//*[@class='grandprice'])[2]")).getText());

		// Get Screenshot
		File BookingConfirmed = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(BookingConfirmed, new File("C:/TC012_CityTour_DhowCruise_Vocuher/BookingConfirmed.jpg"));

		// Download Invoice
		driver.findElement(By.xpath("(.//*[contains(text(),'Download  invoice')])[1]")).click();
		System.out.println("Invoice is printed successfully!");
		Thread.sleep(10000);

		// Click on Voucher Booking for All Tours
		driver.findElement(By.xpath("(.//*[contains(text(),'Voucher All')])[1]")).click();
		Thread.sleep(5000);

		// Issue Voucher
		driver.findElement(By.xpath(".//*[@id='txtAllVoucher1']")).sendKeys("Testing Purpose for Dubai Tours");
		driver.findElement(By.xpath(
				"(.//div[@class='bottom-button']/descendant::a[contains(text(),'Issue Voucher by Credit Limit')])[1]"))
				.click();
		Thread.sleep(10000);

		// Voucher Details
		System.out.println("The booking is"
				+ driver.findElement(By.xpath("(.//*[contains(text(),'Vouchered')])[11]")).getText() + " for "
				+ driver.findElement(By.xpath("((.//*[contains(text(),'Tour Option')])[1]/following::tbody/tr/td)[1]"))
						.getText()
				+ " with price " + driver.findElement(By.xpath("(.//*[@class='grandprice'])[1]")).getText());
		// Tour 2 Confirmation Details
		System.out.println("The booking is"
				+ driver.findElement(By.xpath("(.//*[contains(text(),'Vouchered')])[12]")).getText() + " for "
				+ driver.findElement(By.xpath("((.//*[contains(text(),'Tour Option')])[2]/following::tbody/tr/td)[1]"))
						.getText()
				+ " with price " + driver.findElement(By.xpath("(.//*[@class='grandprice'])[2]")).getText());

		// Get Screenshot
		File TourDetailsAfterVouchering = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(TourDetailsAfterVouchering,
				new File("C:/TC012_CityTour_DhowCruise_Vocuher/TourDetailsAfterVouchering.jpg"));

		// Download Voucher Details
		driver.findElement(By.xpath("(.//*[contains(text(),'Download Voucher')])[1]")).click();
		Thread.sleep(10000);
		driver.findElement(By.xpath("(.//*[contains(text(),'Download Voucher')])[2]")).click();
		Thread.sleep(10000);

		// Check the Credit Limit After Payment
		driver.findElement(By.xpath(".//*[@id='agtCreditLimit']")).click();
		Thread.sleep(10000);
		System.out.println("Credit Limit after Payment = " + driver
				.findElement(By.xpath("(.//*[contains(text(),'Available Limit ')]/following-sibling::span/small)[2]"))
				.getText());
		Thread.sleep(5000);

		// Get Screenshot
		File CreditLimitAfterPayment = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(CreditLimitAfterPayment,
				new File("C:/TC012_CityTour_DhowCruise_Vocuher/CreditLimitAfterPayment.jpg"));

		// View Voucher for Tour 1
		driver.findElement(By.xpath("(.//*[contains(text(),'View Voucher')])[1]")).click();
		Thread.sleep(10000);

		// Details verify from Voucher Page
		driver.findElement(By.xpath("((.//*[@class='logopart'])[1]/div/div/div/img)[1]")).isDisplayed();
		System.out.println("Rayna logo on top left corner is displayed on Voucher details page!");

		System.out.println(
				"Reference Number = " + driver.findElement(By.xpath("(.//*[@class='ref-rt']/h3/span)[1]")).getText());
		System.out.println("PIN = " + driver.findElement(By.xpath("(.//*[@class='ref-rt']/h3/span)[3]")).getText());

		driver.findElement(By.xpath(".//*[@class='ref-rt']/following::div/img")).isDisplayed();
		System.out.println("Bar Code is displayed on Voucher details page!");

		// Get Screenshot
		File VoucherDetailsPage1 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(VoucherDetailsPage1,
				new File("C:/TC009_BurjKhalifaAfter15Days_WithoutGuide/VoucherDetailsPage1.jpg"));

		System.out.println("Booking Date = " + driver
				.findElement(By.xpath("((.//*[contains(text(),'Booking Date')])[1]/following::td/span)[1]")).getText());
		System.out.println("Tour Date = " + driver
				.findElement(By.xpath("((.//*[contains(text(),'Tour Date')])[1]/following::td/span)[1]")).getText());
		System.out.println("Tour Name = " + driver
				.findElement(By.xpath("((.//*[contains(text(),'Tour Details')])[1]/following::td/span)[2]")).getText());
		System.out.println("Transfer Type = " + driver
				.findElement(By.xpath("(.//*[contains(text(),'Transfer Type')])[2]/following::tbody/tr/td")).getText());
		System.out.println("Guest Name = " + driver
				.findElement(By.xpath("((.//*[contains(text(),'Name')])[2]/following::tbody/tr/td)[1]")).getText());
		System.out.println("Guest Email ID = " + driver
				.findElement(By.xpath("((.//*[contains(text(),'Name')])[2]/following::tbody/tr/td)[2]")).getText());
		System.out.println("Guest Mobile Number = " + driver
				.findElement(By.xpath("((.//*[contains(text(),'Name')])[2]/following::tbody/tr/td)[3]")).getText());

		// Close button - close voucher details
		driver.findElement(By.xpath("(.//*[@class='modal-content']/button)[3]")).click();

		// View Voucher for Tour 2
		driver.findElement(By.xpath("(.//*[contains(text(),'View Voucher')])[1]")).click();
		Thread.sleep(10000);

		// Details verify from Voucher Page
		driver.findElement(By.xpath("((.//*[@class='logopart'])[1]/div/div/div/img)[1]")).isDisplayed();
		System.out.println("Rayna logo on top left corner is displayed on Voucher details page!");

		System.out.println(
				"Reference Number = " + driver.findElement(By.xpath("(.//*[@class='ref-rt']/h3/span)[1]")).getText());
		System.out.println("PIN = " + driver.findElement(By.xpath("(.//*[@class='ref-rt']/h3/span)[3]")).getText());

		driver.findElement(By.xpath(".//*[@class='ref-rt']/following::div/img")).isDisplayed();
		System.out.println("Bar Code is displayed on Voucher details page!");

		// Get Screenshot
		File VoucherDetailsTour2 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(VoucherDetailsPage1,
				new File("C:/TC009_BurjKhalifaAfter15Days_WithoutGuide/VoucherDetailsPage1.jpg"));

		System.out.println("Booking Date = " + driver
				.findElement(By.xpath("((.//*[contains(text(),'Booking Date')])[3]/following::span)[1]")).getText());
		System.out.println("Tour Date = " + driver
				.findElement(By.xpath("((.//*[contains(text(),'Tour Date')])[15]/following::span)[1]")).getText());
		System.out.println("Tour Name = " + driver
				.findElement(By.xpath("(.//*[contains(text(),'Tour Details')])[6]/following::span[1]")).getText());
		System.out.println("Transfer Type = " + driver
				.findElement(By.xpath("((.//*[contains(text(),'Transfer Type')])[5]/following::span)[1]")).getText());
		System.out.println("Guest Name = " + driver
				.findElement(By.xpath("((.//*[contains(text(),'Name')])[2]/following::tbody/tr/td)[1]")).getText());
		System.out.println("Guest Email ID = " + driver
				.findElement(By.xpath("((.//*[contains(text(),'Name')])[2]/following::tbody/tr/td)[2]")).getText());
		System.out.println("Guest Mobile Number = " + driver
				.findElement(By.xpath("((.//*[contains(text(),'Name')])[2]/following::tbody/tr/td)[3]")).getText());

		// Close button - close voucher details
		driver.findElement(By.xpath("(.//*[@class='modal-content']/button)[3]")).click();
		Thread.sleep(5000);

		// Get Screenshot
		File TourDetailsAfterCancelling = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(TourDetailsAfterCancelling,
				new File("C:/TC012_CityTour_DhowCruise_Vocuher/TourDetailsAfterCancelling.jpg"));

		// Sign out
		driver.findElement(By.xpath("//a[@href='/Signout.aspx']")).click();
		Thread.sleep(5000);

		// Get Screenshot
		File SignOutPage = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(SignOutPage, new File("C:/TC012_CityTour_DhowCruise_Vocuher/SignOutPage.jpg"));
		System.out.println(
				"Scenarios passed" + "1. Dubai City Tour and Dhow Cruise are vouchered and Cancelled on the same day.");
		System.out.println("Test Script passed successfully!");

		driver.close();
	}

	public static void Login(WebDriver driver) {

		driver.get("https://bookdubaipackage.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);

		// Valid Login
		WebElement Agent = driver.findElement(By.id("txtAgentcode"));
		WebElement userName = driver.findElement(By.id("txtUsername"));
		WebElement pwd = driver.findElement(By.id("txtPassword"));

		Xls_Reader reader = new Xls_Reader("./src/ExcelResults/SampleExcel.xlsx");
		String sheetName = "login";

		int rowCount = reader.getRowCount(sheetName);

		for (int rowNum = 2; rowNum <= rowCount; rowNum++) {
			String AgentCode = reader.getCellData(sheetName, "Agent", rowNum);
			String loginId = reader.getCellData(sheetName, "username", rowNum);
			String passsword = reader.getCellData(sheetName, "password", rowNum);

			System.out.println(AgentCode + " " + loginId + " " + passsword);

			Agent.clear();
			Agent.sendKeys(AgentCode);

			userName.clear();
			userName.sendKeys(loginId);

			pwd.clear();
			pwd.sendKeys(passsword);

			driver.findElement(By.id("btnLogin")).click();
		}
	}

	public static String Homepage() throws InterruptedException {
		String a = "rutuja";
		return a;

	}
}
