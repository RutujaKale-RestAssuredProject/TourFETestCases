package Tour_Bookings;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class centerpoint {

	public static void main(String[] args) throws InterruptedException {
		
		
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Techno\\Desktop\\Automation\\chromedriver.exe");	
		
		ChromeOptions options = new ChromeOptions();
		
		options.addArguments("start-maximized");

		options.addArguments("disable-infobars");

		options.addArguments("--disable-extensions");

		WebDriver driver = new ChromeDriver(options);

		driver.get("https://www.centrepointstores.com/ae/en/");
		driver.findElement(By.xpath("(.//span[@class='MuiButton-label'])[8]")).click();
		driver.findElement(By.xpath(".//span[contains(text(),'Women Shoes')]")).click();
		Thread.sleep(10000);
		
		driver.findElement(By.xpath(".//input[@type='button']")).click();
		Thread.sleep(10000);
		
		driver.findElement(By.id("checkbox")).click();
		Thread.sleep(10000);
				
	}
}
