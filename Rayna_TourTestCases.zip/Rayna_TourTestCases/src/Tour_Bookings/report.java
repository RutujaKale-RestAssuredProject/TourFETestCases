package Tour_Bookings;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;

public class report {

	public static void main(String[] args) throws Exception {

		// Launching the chrome browser
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Techno\\Desktop\\Automation\\Drivers\\Chrome\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();

		// Opening the demo site - wordpress.com
		driver.get("https://wordpress.com/start/about?ref=create-blog-lp");

		// Locating the Test data excel file
		String excelPath = "C:\\Users\\Techno\\Desktop\\Automation\\abc.xlsx";
		System.out.println(excelPath);

		Fillo fillo = new Fillo();
		Connection connection = fillo.getConnection(excelPath);
		String strSelectQuerry = "Select * from  Data";
		System.out.println(strSelectQuerry);

		Recordset recordset = null;
		recordset = connection.executeQuery(strSelectQuerry);

		while (recordset.next()) {

			System.out.println("Column 1 = " + recordset.getField("SiteTitle"));
			String siteTitle = recordset.getField("SiteTitle");

			driver.findElement(By.xpath("//input[@name='siteTitle']")).clear();

			driver.findElement(By.xpath("//input[@name='siteTitle']")).sendKeys(siteTitle);

			System.out.println("Column 2 = " + recordset.getField("SiteTopic"));
			String siteTopic = recordset.getField("SiteTopic");

			driver.findElement(By.xpath("//input[@name='siteTopic']")).clear();

			driver.findElement(By.xpath("//input[@name='siteTopic']")).sendKeys(siteTopic);

			connection.close();

		}
		// Use update query to update the details in excel file
		Connection connection1 = fillo.getConnection(excelPath);

		System.out.println("Column 1 value before Update clause = " + recordset.getField("SiteTitle"));
		String strUpdateQuerry = "Update Data Set SiteTitle = 'SoftwareTestingHelp.com'";

		System.out.println(strUpdateQuerry);
		connection1.executeUpdate(strUpdateQuerry);

		System.out.println("Column 1 value after Update clause = " + recordset.getField("SiteTitle"));

		// Use Insert query to update the data in excel sheet
		Connection connection2 = fillo.getConnection(excelPath);

		String strInsertQuerry = "INSERT INTO Data (SiteTitle,SiteTopic) Values('Bharat','NewDelhi')";
		System.out.println(strInsertQuerry);

		connection2.executeUpdate(strInsertQuerry);

		System.out.println("Column 1 and column 2 value after insert clause = " + recordset.getField("SiteTitle")
				+ recordset.getField("siteTopic"));

	}

}
