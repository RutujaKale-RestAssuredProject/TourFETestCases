package Tour_Bookings;

public interface SelectTour {

}
