package Tour_Bookings;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import org.apache.maven.shared.utils.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.excel.lib.util.Xls_Reader;

import PageObjects.AllDates;

	public class TC003_DhowCruise_CurrentDate extends AllDates {

		public static void main(String[] args) throws Exception {

			DhowCruise_ConfirmBooking();
		}		  

		@Test(priority=0)
		public static void DhowCruise_ConfirmBooking() throws InterruptedException, Exception {
			//Login
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\Techno\\Desktop\\Automation\\Drivers\\Chrome\\chromedriver.exe");
			WebDriver driver = new ChromeDriver();
	        driver.get("https://bookdubaipackage.com/");
	        driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			
	        //Valid Login
			WebElement Agent = driver.findElement(By.id("txtAgentcode"));
			WebElement userName = driver.findElement(By.id("txtUsername"));
			WebElement pwd = driver.findElement(By.id("txtPassword"));	

			Xls_Reader reader = new Xls_Reader("./src/ExcelResults/SampleExcel.xlsx");
			String sheetName = "login";

			int rowCount = reader.getRowCount(sheetName);

			for(int rowNum=2; rowNum<=rowCount; rowNum++) {
				String AgentCode = reader.getCellData(sheetName, "Agent", rowNum);
				String loginId = reader.getCellData(sheetName, "username", rowNum);
				String passsword = reader.getCellData(sheetName, "password", rowNum);

				System.out.println(AgentCode + " " + loginId + " " + passsword);

				Agent.clear();
				Agent.sendKeys(AgentCode);

				userName.clear();
				userName.sendKeys(loginId);

				pwd.clear();
				pwd.sendKeys(passsword);
				driver.findElement(By.id("btnLogin")).click(); 
				Thread.sleep(10000);
	  	  	
	  	
	     	//Filter for Tour
	     	driver.findElement(By.id("txtCityNameTour")).clear(); //Enter City or Destination name
	     	driver.findElement(By.id("txtCityNameTour")).sendKeys("Dubai");
	     	
	     	//Get Screenshot
	     	File Homepage = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	     	FileUtils.copyFile(Homepage, new File("C:/TC003_DhowCruise_CurrentDate/Homepage.jpg"));
	     	Thread.sleep(5000);
	     	
	     	//Change the currency to AED
	     	driver.findElement(By.xpath(".//*[@id='sysCurr']")).click();
	     	driver.findElement(By.xpath(".//ul[@class='dropdown-content']/li/a[@title='AED']")).click();
	     	Thread.sleep(5000);
	     	
	     	//Click on Search button
	     	driver.findElement(By.id("btnTourSearch")).click();
	     	Thread.sleep(5000);
	     	
	     	//Select Tour
	     	WebElement Tour_Name = driver.findElement(By.xpath(".//*[contains(text(),'Dhow Cruise Dinner - Creek')]"));
	     	Tour_Name.click();
	     	System.out.println("Dhow Cruise Dinner - Creek is clicked!");
	     	Thread.sleep(5000);
	     	
			//Switch to new window and verify the title
	     	for(String winHandle : driver.getWindowHandles()){
	     	    driver.switchTo().window(winHandle);
	     	}
	    	Thread.sleep(5000);
	    	
	     	//Enter the current date
	     	driver.findElement(By.xpath("(.//*[@class='datepickTD'])[1]/div/div/input")).clear();
	     	driver.findElement(By.xpath("(.//*[@class='datepickTD'])[1]/div/div/input")).sendKeys(AllDates.CurrentDate(0));
	     	System.out.println("Current Date = " + AllDates.CurrentDate(0) + "is entered");
	     	
	    	System.out.println("Tour Details Fetched for = " + driver.findElement(By.xpath(".//div[@class='ProductNameReviews']/h1[contains(text(),'Dhow Cruise Dinner - Creek')]")).getText());
	     	Thread.sleep(5000);
	     	
	     	//Get Screenshot
	     	File TourDetails = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	     	FileUtils.copyFile(TourDetails, new File("C:/TC003_DhowCruise_CurrentDate/TourDetails.jpg"));
	     	
	     	driver.findElement(By.id("addToCartDetails")).click(); //click on Add To Cart button	
	     	Thread.sleep(5000);
	     	
	     	//Get Screenshot
	     	File PassengerDetails = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	     	FileUtils.copyFile(PassengerDetails, new File("C:/TC003_DhowCruise_CurrentDate/PassengerDetails.jpg")); 	
	     	
	       //Verify the Alert Message 
	     	System.out.println("Alert Message displayed as - " + driver.findElement(By.xpath("(.//*[@id='dispMessage'])[1]")).getText());
	     	driver.findElement(By.xpath("(.//button[@class='ThemeButton'][contains(text(),'Ok')])[2]")).click();

	     	System.out.println("Test Script passed successfully!");
	    	Thread.sleep(5000);
	    	
	    	driver.close();
	    	
		}		
     }
}