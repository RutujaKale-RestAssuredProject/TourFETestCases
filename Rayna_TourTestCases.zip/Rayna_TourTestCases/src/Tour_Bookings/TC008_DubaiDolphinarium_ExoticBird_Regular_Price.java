package Tour_Bookings;

import static org.testng.Assert.assertTrue;
import java.io.File;
import java.util.concurrent.TimeUnit;
import org.apache.maven.shared.utils.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import com.excel.lib.util.Xls_Reader;

import PageObjects.AllDates;

public class TC008_DubaiDolphinarium_ExoticBird_Regular_Price {

	public static void main(String[] args) throws Exception {

		DubaiDolphinarium_ExoticBird_Regular_Price();
	}

	@Test(priority = 0)
	public static void DubaiDolphinarium_ExoticBird_Regular_Price() throws InterruptedException, Exception {
		//Login
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Techno\\Desktop\\Automation\\Drivers\\Chrome\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://bookdubaipackage.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);

		//Valid Login
		WebElement Agent = driver.findElement(By.id("txtAgentcode"));
		WebElement userName = driver.findElement(By.id("txtUsername"));
		WebElement pwd = driver.findElement(By.id("txtPassword"));	

		Xls_Reader reader = new Xls_Reader("./src/ExcelResults/SampleExcel.xlsx");
		String sheetName = "login";

		int rowCount = reader.getRowCount(sheetName);

		for(int rowNum=2; rowNum<=rowCount; rowNum++){
			String AgentCode = reader.getCellData(sheetName, "Agent", rowNum);
			String loginId = reader.getCellData(sheetName, "username", rowNum);
			String passsword = reader.getCellData(sheetName, "password", rowNum);

			System.out.println(AgentCode + " " + loginId + " " + passsword);

			Agent.clear();
			Agent.sendKeys(AgentCode);

			userName.clear();
			userName.sendKeys(loginId);

			pwd.clear();
			pwd.sendKeys(passsword);
			driver.findElement(By.id("btnLogin")).click(); 
			Thread.sleep(10000);   	  	   	  	

		// Filter for Tour
		driver.findElement(By.id("txtCityNameTour")).clear(); // Enter City or Destination name
		driver.findElement(By.id("txtCityNameTour")).sendKeys("Dubai");

		// Get Screenshot
		File Homepage = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(Homepage, new File("C:/TC008_DubaiDolphinarium_ExoticBird_Regular_Price/Homepage.jpg"));
		Thread.sleep(5000);

		// Change the currency to AED
		driver.findElement(By.xpath(".//*[@id='sysCurr']")).click();
		driver.findElement(By.xpath(".//ul[@class='dropdown-content']/li/a[@title='AED']")).click();
		System.out.println("AED currency is selected!");
		Thread.sleep(5000);

		// Click on Search button
		driver.findElement(By.id("btnTourSearch")).click();
		Thread.sleep(5000);

		WebDriverWait wait = new WebDriverWait(driver, 10);
		      WebElement PriceLoading = wait.until(
		             ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='PriceBoxRight']")));
		      PriceLoading.isDisplayed();

		// Select Tour
		driver.findElement(By.id("toursearchtext")).sendKeys("Dolphinarium");
		WebElement Tour_Name = driver.findElement(By.xpath(".//*[contains(text(),'Dubai Dolphinarium')]"));
		Tour_Name.click();
		System.out.println("Dubai Dolphinarium is clicked!");
		Thread.sleep(5000);

		// Switch to new window and verify the title
		for (String winHandle : driver.getWindowHandles()) {
		driver.switchTo().window(winHandle);
		}
		Thread.sleep(5000);

		System.out.println("Tour Details Fetched for = " + driver
		.findElement(By.xpath(".//div[@class='ProductNameReviews']/h1[contains(text(),'Dubai Dolphinarium')]"))
		.getText());
		Thread.sleep(5000);

		// Regular Ticket Selection
		System.out.println("Tour name 1 = " + driver.findElement(By.xpath("(.//*[@class='TourOP']/div)[1]")).getText());
		// Transfer Type - Without Transfer
		// Enter the future date
		driver.findElement(By.xpath("(.//*[@class='datepickTD'])[1]/div/div/input")).clear();
		driver.findElement(By.xpath("(.//*[@class='datepickTD'])[1]/div/div/input")).sendKeys(AllDates.Futurdate(0));
		System.out.println("Date Entered = " + AllDates.Futurdate(0));
		// PAX
		driver.findElement(By.xpath("(.//*[@class='paxTD'])[1]")).click();
		driver.findElement(By.xpath("((.//*[@class='paxTD'])[1]/div/span/following::select/option[@value='1'])[1]"))
		.click();
		driver.findElement(By.xpath("(.//*[@class='paxTD'])[2]")).click();
		driver.findElement(By.xpath("((.//*[@class='paxTD'])[2]/div/span/following::select/option[@value='2'])[1]"))
		.click();
		// Price calculated for tour 1
		String PriceTour1 = driver.findElement(By.xpath("((.//span[@class='OrigionalPrice'])/span[2])[2]")).getText();
		System.out.println("Price for Tour 1 = " + PriceTour1);

		// Exotic Bird Show Ticket selection
		System.out.println("Tour name 2 = " + driver.findElement(By.xpath("(.//*[@class='TourOP']/div)[2]")).getText());
		driver.findElement(By.xpath("(.//*[@class='TourOP']/div)[2]")).click();
		// Transfer Type - Without Transfer
		// Enter the future date
		driver.findElement(By.xpath("(.//*[@class='datepickTD'])[2]/div/div/input")).clear();
		driver.findElement(By.xpath("(.//*[@class='datepickTD'])[2]/div/div/input")).sendKeys(AllDates.Futurdate(0));
		System.out.println("Date Entered = " + AllDates.Futurdate(0));
		// PAX
		driver.findElement(By.xpath("(.//*[@class='paxTD'])[1]")).click();
		driver.findElement(By.xpath("((.//*[@class='paxTD'])[1]/div/span/following::select/option[@value='1'])[1]"))
		.click();
		driver.findElement(By.xpath("(.//*[@class='paxTD'])[2]")).click();
		driver.findElement(By.xpath("((.//*[@class='paxTD'])[2]/div/span/following::select/option[@value='2'])[1]"))
		.click();
		// Price calculated for tour 2
		String PriceTour2 = driver.findElement(By.xpath("((.//span[@class='OrigionalPrice'])/span[2])[2]")).getText();
		System.out.println("Price for Tour 2 = " + PriceTour2);

		// Get Screenshot
		File TourDetails = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(TourDetails,
		new File("C:/TC008_DubaiDolphinarium_ExoticBird_Regular_Price/TourDetails.jpg"));

		driver.findElement(By.id("addToCartDetails")).click(); // click on Add To Cart button
		Thread.sleep(5000);

		// Book timing for Regular show
		System.out.println("Book Timing for Show = " + driver
		.findElement(By.xpath("(.//*[contains(text(),'Dolphin & Seal Show Regular Tickets')])[4]")).getText());
		driver.findElement(By.xpath("(.//*[@class='slotList' ]/li/a/div)[1]")).click();
		File SlotTimeTour1 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(SlotTimeTour1,
		new File("C:/TC008_DubaiDolphinarium_ExoticBird_Regular_Price/SlotTimeTour1.jpg"));
		System.out.println("Book Timing = 11 am selected!");

		driver.findElement(By.xpath("(.//*[contains(text(),'Change')])[2]")).click();
		driver.findElement(By.xpath(".//*[contains(text(),'2) Exotic Bird Show')]")).click();

		// Book timing for Exotic Bird show
		System.out.println("Book Timing for Show = "
		+ driver.findElement(By.xpath("(.//*[contains(text(),'Exotic Bird Show')])[4]")).getText());
		driver.findElement(By.xpath("(.//*[@class='slotList' ]/li/a/div)[1]")).click();
		File SlotTimeTour2 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(SlotTimeTour2,
		new File("C:/TC008_DubaiDolphinarium_ExoticBird_Regular_Price/SlotTimeTour2.jpg"));
		System.out.println("Book Timing = 12.15 pm selected!");
		driver.findElement(By.xpath(".//*[contains(text(),'PROCEED')]")).click();
		Thread.sleep(5000);
		
		// Tour Name 1
		System.out.println("Tour Option selected = " + driver.findElement(By.xpath("((.//*[contains(text(),'Tour Option')])[1])/following::div[1]")).getText());
		Thread.sleep(5000);
		// Transfer Type
		System.out.println("Transfer Type = " + driver.findElement(By.xpath("(.//li/div[contains(text(),'Transfer Type')])[1]/following-sibling::div[1]")).getText());
		// Confirm Booking Date
		System.out.println("Booking Date = "
		+ driver.findElement(By.xpath("(.//*[contains(text(),'Date')]/following-sibling::div)[1]")).getText());
		// Confirm Booking Time
		System.out.println("Booking Time = "
		+ driver.findElement(By.xpath("(.//*[contains(text(),'Time')]/following-sibling::div)[1]")).getText());
		// PAX
		System.out.println("PAX = "
		+ driver.findElement(By.xpath("(.//*[contains(text(),'Pax')]/following-sibling::div)[1]")).getText());
		// Total Amount for Tour1
		System.out.println("Total Amount for Tour option 1 = "
		+ driver.findElement(By.xpath("(.//*[contains(text(),'Total')]/following-sibling::div)[1]")).getText());

		// Tour Name 2
		System.out.println("Tour Option selected = "
		+ driver.findElement(By.xpath("((.//*[contains(text(),'Tour Option')])[2])/following::div[1]")).getText());
		Thread.sleep(5000);
		// Transfer Type
		System.out.println("Transfer Type = " + driver
		.findElement(By.xpath("(.//li/div[contains(text(),'Transfer Type')])[2]/following-sibling::div[1]")).getText());
		// Confirm Booking Date
		System.out.println("Booking Date = "
		+ driver.findElement(By.xpath("(.//*[contains(text(),'Date')]/following-sibling::div)[2]")).getText());
		// Confirm Booking Time
		System.out.println("Booking Time = "
		+ driver.findElement(By.xpath("(.//*[contains(text(),'Time')]/following-sibling::div)[2]")).getText());
		// PAX
		System.out.println("PAX = "
		+ driver.findElement(By.xpath("(.//*[contains(text(),'Pax')]/following-sibling::div)[2]")).getText());
		// Total Amount for Tour1
		System.out.println("Total Amount for Tour option 2 = "
		+ driver.findElement(By.xpath("(.//*[contains(text(),'Total')]/following-sibling::div)[2]")).getText());

		// Confirm Final Payment
		System.out.println("Final Payment to be done for all tours = " + driver
		.findElement(By.xpath(".//*[contains(text(),'Final Payment')]/following-sibling::p")).getText());

		// Enter Passenger Details
		driver.findElement(By.id("txtFirstNameNew")).sendKeys("Sujit");
		System.out.println("First Name is given");
		driver.findElement(By.id("txtLastNameNew")).sendKeys("Patil");
		System.out.println("Last Name is given");

		// Get Screenshot
		File PassengerInfo = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(PassengerInfo,
		new File("C:/TC008_DubaiDolphinarium_ExoticBird_Regular_Price/PassengerInfo.jpg"));

		// Email ID and Phone Number
		System.out.println(driver.findElement(By.id("txtEmail")).getText());
		System.out.println(driver.findElement(By.id("txtPhNo")).getText());

		// Payment Options
		driver.findElement(By.id("CreditLimit_licred")).click(); // Radio button for Credit Limit for payment is
		// selected
		driver.findElement(By.className("checkmark")).click(); // Accept the Terms & Conditions

		// Get Screenshot
		File PaymentOption = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(PaymentOption,
		new File("C:/TC008_DubaiDolphinarium_ExoticBird_Regular_Price/PaymentOption.jpg"));

		// Check the Credit Limit Before Payment
		driver.findElement(By.xpath(".//li[@class='dropdown ']/a[contains(text(),'Credit Limit')]")).click();
		System.out.println("Credit Limit Before Payment = " + driver
		.findElement(By.xpath("(.//*[contains(text(),'Available Limit ')]/following-sibling::span/small)[2]"))
		.getText());
		Thread.sleep(5000);

		// Get Screenshot
		File CreditLimitBeforePayment = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(CreditLimitBeforePayment,
		new File("C:/TC008_DubaiDolphinarium_ExoticBird_Regular_Price/CreditLimitBeforePayment.jpg"));

		// Pay on Pay By Credit Limit
		driver.findElement(By.xpath(".//*[contains(text(),'Pay By Credit Limit')]")).click();
		Thread.sleep(5000);

		// Get Screenshot
		File TourDetailsBeforePayment = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(TourDetailsBeforePayment,
		new File("C:/TC008_DubaiDolphinarium_ExoticBird_Regular_Price/TourDetailsBeforePayment.jpg"));

		// Click on confirm Booking option
		driver.findElement(By.xpath(".//*[contains(text(),'I agree to Confirm my Booking')]")).click();
		Thread.sleep(5000);

		// Tour 1 Confirmation Details
		System.out.println("The booking is confirmed for"
		+ driver.findElement(By.xpath("((.//*[contains(text(),'Tour Option')])[1]/following::tbody/tr/td)[1]"))
		.getText()
		+ " with price " + driver.findElement(By.xpath("(.//*[@class='grandprice'])[1]")).getText());
		// Tour 2 Confirmation Details
		System.out.println("The booking is confirmed for"
		+ driver.findElement(By.xpath("((.//*[contains(text(),'Tour Option')])[2]/following::tbody/tr/td)[1]"))
		.getText()
		+ " with price " + driver.findElement(By.xpath("(.//*[@class='grandprice'])[2]")).getText());

		// Get Screenshot
		File BookingConfirmed = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(BookingConfirmed,
		new File("C:/TC008_DubaiDolphinarium_ExoticBird_Regular_Price/BookingConfirmed.jpg"));

		// Download Invoice
		driver.findElement(By.xpath("(.//*[contains(text(),'Download  invoice')])[1]")).click();
		System.out.println("Invoice is printed successfully!");
		Thread.sleep(10000);

		// Click on Voucher Booking for All Tours
		driver.findElement(By.xpath("(.//*[contains(text(),'Voucher All')])[1]")).click();
		Thread.sleep(5000);

		// Issue Voucher
		driver.findElement(By.xpath(".//*[@id='txtAllVoucher1']")).sendKeys("Testing Purpose for Dubai Tours");
		driver.findElement(By.xpath(
		"(.//div[@class='bottom-button']/descendant::a[contains(text(),'Issue Voucher by Credit Limit')])[1]"))
		.click();
		Thread.sleep(10000);

		// Voucher Details
		System.out.println("The booking is"
		+ driver.findElement(By.xpath("(.//*[contains(text(),'Vouchered')])[11]")).getText() + " for "
		+ driver.findElement(By.xpath("((.//*[contains(text(),'Tour Option')])[1]/following::tbody/tr/td)[1]"))
		.getText()
		+ " with price " + driver.findElement(By.xpath("(.//*[@class='grandprice'])[1]")).getText());
		// Tour 2 Confirmation Details
		System.out.println("The booking is"
		+ driver.findElement(By.xpath("(.//*[contains(text(),'Vouchered')])[12]")).getText() + " for "
		+ driver.findElement(By.xpath("((.//*[contains(text(),'Tour Option')])[2]/following::tbody/tr/td)[1]"))
		.getText()
		+ " with price " + driver.findElement(By.xpath("(.//*[@class='grandprice'])[2]")).getText());

		// Get Screenshot
		File TourDetailsAfterVouchering = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(TourDetailsAfterVouchering,
		new File("C:/TC008_DubaiDolphinarium_ExoticBird_Regular_Price/TourDetailsAfterVouchering.jpg"));

		// Download Voucher Details
		driver.findElement(By.xpath("(.//*[contains(text(),'Download Voucher')])[1]")).click();
		Thread.sleep(10000);
		driver.findElement(By.xpath("(.//*[contains(text(),'Download Voucher')])[2]")).click();
		Thread.sleep(10000);

		// Download Ticket
		driver.findElement(By.xpath("(.//*[contains(text(),'Download Ticket')])[1]")).click();
		Thread.sleep(10000);
		driver.findElement(By.xpath("(.//*[contains(text(),'Download Ticket')])[2]")).click();
		Thread.sleep(10000);

		// Check the Credit Limit After Payment
		driver.findElement(By.xpath(".//*[@id='agtCreditLimit']")).click();
		Thread.sleep(10000);
		System.out.println("Credit Limit after Payment = " + driver
		.findElement(By.xpath("(.//*[contains(text(),'Available Limit ')]/following-sibling::span/small)[2]"))
		.getText());
		Thread.sleep(5000);

		// Get Screenshot
		File CreditLimitAfterPayment = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(CreditLimitAfterPayment,
		new File("C:/TC008_DubaiDolphinarium_ExoticBird_Regular_Price/CreditLimitAfterPayment.jpg"));

		// Cancel Booking not available
		if (driver.findElement(By.xpath(".//*[contains(text(),'Cancel Booking')]")).isEnabled())
		;
		{
		System.out.println("Booking can be Cancelled as the Cancel Booking Button is present");
		}
		{
		System.out.println("Booking can't be Cancelled as the Cancel Booking Button is not present");

		}
		Thread.sleep(5000);

		// Get Screenshot
		File TourDetailsAfterCancelling = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(TourDetailsAfterCancelling,
		new File("C:/TC008_DubaiDolphinarium_ExoticBird_Regular_Price/TourDetailsAfterCancelling.jpg"));

		// Sign out
		driver.findElement(By.xpath("//a[@href='/Signout.aspx']")).click();
		Thread.sleep(5000);

		// Get Screenshot
		File SignOutPage = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(SignOutPage,
		new File("C:/TC008_DubaiDolphinarium_ExoticBird_Regular_Price/SignOutPage.jpg"));
		System.out.println("Scenarios passed"
		+ "1. If one tour is Refunadable and another is non-refundable all tours will be counted as Non-Refundable"
		+ "2. Bookings can't be cancelled as both tours vouchered as Non-Refundable Tours");
		System.out.println("Test Script passed successfully!");

		driver.close();
		}
   }
}

