package Tour_Bookings;

import java.io.File;
import java.util.concurrent.TimeUnit;
import org.apache.maven.shared.utils.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import com.excel.lib.util.Xls_Reader;
import PageObjects.AllDates;

public class TC002_B2CUAEAttractions {

	public static void main(String[] args) throws Exception {

		B2CUAEAttractions();
	}

	@Test(priority = 0)
	public static void B2CUAEAttractions() throws InterruptedException, Exception {
		//Login
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Techno\\Desktop\\Automation\\Drivers\\Chrome\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://b2c.uaeattractions.com/login");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);

		//Valid Login
		WebElement Agent = driver.findElement(By.id("txtAgentcode"));
		WebElement userName = driver.findElement(By.id("txtUsername"));
		WebElement pwd = driver.findElement(By.id("txtPassword"));	

		Xls_Reader reader = new Xls_Reader("./src/ExcelResults/SampleExcel.xlsx");
		String sheetName = "login";

		int rowCount = reader.getRowCount(sheetName);

		for(int rowNum=2; rowNum<=rowCount; rowNum++){
			String AgentCode = reader.getCellData(sheetName, "Agent", rowNum);
			String loginId = reader.getCellData(sheetName, "username", rowNum);
			String passsword = reader.getCellData(sheetName, "password", rowNum);

			System.out.println(AgentCode + " " + loginId + " " + passsword);

			Agent.clear();
			Agent.sendKeys(AgentCode);

			userName.clear();
			userName.sendKeys(loginId);

			pwd.clear();
			pwd.sendKeys(passsword);

			driver.findElement(By.id("btnLogin")).click(); 
			Thread.sleep(10000);   	  	

			// Filter for Tour
			driver.findElement(By.id("txtCityNameTour")).clear(); // Enter City or Destination name
			driver.findElement(By.id("txtCityNameTour")).sendKeys("Dubai");

			// Get Screenshot
			File Homepage = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(Homepage, new File("C:/TC011_DubaiFountainShow_VoucherBooking_CheckSeats/Homepage.jpg"));
			Thread.sleep(5000);

			// Change the currency to AED
			driver.findElement(By.xpath(".//*[@id='sysCurr']")).click();
			driver.findElement(By.xpath(".//ul[@class='dropdown-content']/li/a[@title='AED']")).click();
			System.out.println("AED currency is selected!");
			Thread.sleep(5000);

			// Click on Search button
			driver.findElement(By.id("btnTourSearch")).click();
			Thread.sleep(5000);

			WebDriverWait wait = new WebDriverWait(driver, 10);
			WebElement PriceLoading = wait.until(
					ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='PriceBoxRight']")));
			PriceLoading.isDisplayed();

			// Select Tour
			driver.findElement(By.id("toursearchtext")).sendKeys("Fountain");
			Thread.sleep(10000);
			WebElement Tour_Name = driver.findElement(By.xpath(".//*[contains(text(),'Dubai Fountain Show and Lake Ride')]"));
			Tour_Name.click();
			System.out.println("Dubai Fountain Show and Lake Ride Tour is clicked!");
			Thread.sleep(5000);

			// Switch to new window and verify the title	
			for (String winHandle : driver.getWindowHandles()) {
				driver.switchTo().window(winHandle);
			}
			Thread.sleep(5000);

			// Scroll Down
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,-2000)", "");
			Thread.sleep(5000);

			System.out.println("Tour Details Fetched for = " + driver
					.findElement(By.xpath("(.//*[contains(text(),'Dubai Fountain Show And Lake Ride')])[2]"))
			.getText());
			Thread.sleep(5000);

			//Walk Bridge
			System.out.println("Tour name 1 = " + driver.findElement(By.xpath("(.//*[@class='TourOP']/div)[1]/span")).getText());
			// Transfer Type - Without Transfer
			// Enter the future date after 20 Days
			driver.findElement(By.xpath("(.//*[@class='datepickTD'])[1]/div/div/input")).clear();
			driver.findElement(By.xpath("(.//*[@class='datepickTD'])[1]/div/div/input")).sendKeys(AllDates.Futurdate20(0));
			System.out.println("Date Entered = " + AllDates.Futurdate20(0));
			// Price calculated for tour 1
			String PriceTour1 = driver.findElement(By.xpath("((.//span[@class='OrigionalPrice'])/span[2])[2]")).getText();
			System.out.println("Price for Tour 1 = " + PriceTour1);

			// Get Screenshot
			File TourDetails = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(TourDetails,
					new File("C:/TC011_DubaiFountainShow_VoucherBooking_CheckSeats/TourDetails.jpg"));

			driver.findElement(By.id("addToCartDetails")).click(); // click on Add To Cart button
			Thread.sleep(15000);

			// Book timing for tour 1
			System.out.println("Book Timing for Show = " + driver
					.findElement(By.xpath("((.//*[@class='toggleBTN'])[2]/following::span)[1]")).getText());		 
			WebElement TimeLoading = wait.until(
					ExpectedConditions.visibilityOfElementLocated(By.xpath("(.//*[@class='slotList' ]/li/a/div)[1]")));
			TimeLoading.isDisplayed();
			driver.findElement(By.xpath("(.//*[@class='slotList' ]/li/a/div)[1]")).click();
			System.out.println("Book Timing = 19:45 pm selected!");		
			System.out.println("Total Seats Available = " + driver.findElement(By.xpath("(.//*[@class='slotList' ]/li/a/div)[1]")).getText());
			//select 20 seats
			driver.findElement(By.id("ddlTimeSlotAdult")).click();
			driver.findElement(By.xpath(".//*[@id='ddlTimeSlotAdult']/option[@value='4']")).click();
			System.out.println("5 Adults selected!");	

			driver.findElement(By.xpath(".//*[contains(text(),'PROCEED')]")).click();
			Thread.sleep(10000);

			WebElement NavToPassengerDetails = wait.until(
					ExpectedConditions.visibilityOfElementLocated(By.xpath("((.//*[contains(text(),'Tour Option')])[1])/following::div[1]")));
			NavToPassengerDetails.isDisplayed();

			// Tour Name 1
			System.out.println("Tour Option 1 Details are as below:");
			System.out.println("Tour Option selected = " + driver.findElement(By.xpath("((.//*[contains(text(),'Tour Option')])[1])/following::div[1]")).getText());
			Thread.sleep(5000);
			// Transfer Type
			System.out.println("Transfer Type = " + driver.findElement(By.xpath("(.//li/div[contains(text(),'Transfer Type')])[1]/following-sibling::div[1]")).getText());
			// Confirm Booking Date
			System.out.println("Booking Date = "
					+ driver.findElement(By.xpath("(.//*[contains(text(),'Date')]/following-sibling::div)[1]")).getText());
			// Confirm Booking Time
			System.out.println("Booking Time = "
					+ driver.findElement(By.xpath("(.//*[contains(text(),'Time')]/following-sibling::div)[1]")).getText());
			// PAX
			System.out.println("PAX = "
					+ driver.findElement(By.xpath("(.//*[contains(text(),'Pax')]/following-sibling::div)[1]")).getText());
			// Total Amount for Tour1
			System.out.println("Total Amount for Tour option 1 = "
					+ driver.findElement(By.xpath("(.//*[contains(text(),'Total')]/following-sibling::div)[1]")).getText());

			// Confirm Final Payment
			System.out.println("Final Payment to be done for all tours = " + driver
					.findElement(By.xpath(".//*[contains(text(),'Final Payment')]/following-sibling::p")).getText());

			// Enter Passenger Details
			driver.findElement(By.id("txtFirstNameNew")).sendKeys("Rutuja");
			System.out.println("First Name is given");
			driver.findElement(By.id("txtLastNameNew")).sendKeys("Test");
			System.out.println("Last Name is given");

			// Get Screenshot
			File PassengerInfo = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(PassengerInfo,
					new File("C:/TC002_B2CUAEAttractions/PassengerInfo.jpg"));

			// Email ID and Phone Number
			System.out.println(driver.findElement(By.id("txtEmail")).getText());
			System.out.println(driver.findElement(By.id("txtPhNo")).getText());

			// Payment Options
			driver.findElement(By.id("CreditLimit_licred")).click(); // Radio button for Credit Limit for payment is
			// selected
			driver.findElement(By.className("checkmark")).click(); // Accept the Terms & Conditions

			// Get Screenshot
			File PaymentOption = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(PaymentOption,
					new File("C:/TC002_B2CUAEAttractions/PaymentOption.jpg"));

			// Check the Credit Limit Before Payment
			driver.findElement(By.xpath(".//li[@class='dropdown ']/a[contains(text(),'Credit Limit')]")).click();
			System.out.println("Credit Limit Before Payment = " + driver
					.findElement(By.xpath("(.//*[contains(text(),'Available Limit ')]/following-sibling::span)"))
			.getText());
			Thread.sleep(5000);

			// Get Screenshot
			File CreditLimitBeforePayment = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(CreditLimitBeforePayment,
					new File("C:/TC002_B2CUAEAttractions/CreditLimitBeforePayment.jpg"));

			// Pay on Pay By Credit Limit
			driver.findElement(By.xpath(".//*[contains(text(),'Pay By Credit Limit')]")).click();
			Thread.sleep(5000);

			// Get Screenshot
			File TourDetailsBeforePayment = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(TourDetailsBeforePayment,
					new File("C:/TC002_B2CUAEAttractions/TourDetailsBeforePayment.jpg"));

			// Click on confirm Booking option
			driver.findElement(By.xpath(".//*[contains(text(),'I agree to Confirm my Booking')]")).click();
			Thread.sleep(5000);

			// Tour 1 Details
			System.out.println("The booking is In Queue for Tour 1 = "
					+ driver.findElement(By.xpath("((.//*[contains(text(),'Tour Option')])[1]/following::tbody/tr/td)[1]"))
					.getText()
					+ " with price " + driver.findElement(By.xpath("(.//*[@class='grandprice'])[1]")).getText() + "Status = " + driver.findElement(By.xpath("(.//*[contains(text(),'Booking Status')])[1]/following::td[10]")).getText());

			// Get Screenshot
			File TourDetailsConfirmed1 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(TourDetailsConfirmed1,
					new File("C:/TC002_B2CUAEAttractions/TourDetailsConfirmed1.jpg"));

			// Download Invoice
			driver.findElement(By.xpath("(.//*[contains(text(),'Download  invoice')])[1]")).click();
			System.out.println("Invoice is printed successfully!");
			Thread.sleep(10000);

			//View Invoice
			driver.findElement(By.xpath("(.//*[contains(text(),'View invoice')])[1]")).click();
			System.out.println("Invoice is opened successfully!");
			Thread.sleep(10000);

			// Details verify from Invoice Page
			WebElement Logo = wait.until(
					ExpectedConditions.visibilityOfElementLocated(By.xpath("(.//*[@class='logopart']/div)[1]")));
			Logo.isDisplayed();

			System.out.println("Agent logo on top left corner is displayed on Invoice details page!");
			driver.findElement(By.xpath("(.//*[@class='logopart']/div[2])[1]/div/div/img")).isDisplayed();
			System.out.println("Rayna logo on top right corner is displayed on Invoice details page!");

			//Reference Details
			System.out.println(
					"Reference Number = " + driver.findElement(By.xpath("(.//*[@class='ref-details']/div/div/table/tbody/tr/td)[1]")).getText());
			System.out.println(
					"Guest Name = " + driver.findElement(By.xpath("(.//*[@class='ref-details']/div/div/table/tbody/tr/td)[2]")).getText());
			System.out.println(
					"Payment Type = " + driver.findElement(By.xpath("(.//*[@class='ref-details']/div/div/table/tbody/tr/td)[5]")).getText());
			System.out.println(
					"Agent Email Id = " + driver.findElement(By.xpath("(.//*[@class='ref-details']/div/div/table/tbody/tr/td)[6]")).getText());
			System.out.println(
					"Agent Mobile No. = " + driver.findElement(By.xpath("(.//*[@class='ref-details']/div/div/table/tbody/tr/td)[7]")).getText());

			// Get Screenshot
			File InvoiceDetailsPage1 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(InvoiceDetailsPage1,
					new File("C:/TC002_B2CUAEAttractions/InvoiceDetailsPage1.jpg"));

			//Service Type
			System.out.println(
					"Service Type = " + driver.findElement(By.xpath("(.//*[@class='servic']/div)[2]")).getText());

			//Tour Details
			System.out.println("The booking is confirmed for Tour 1 = "
					+ driver.findElement(By.xpath("(.//*[@class='ht-name'])[1]"))
					.getText()
					+ " with price " + driver.findElement(By.xpath("((.//*[contains(text(),'Total Amount:')])[1]/following::tbody/tr/td)[5]")).getText() + "Dated = " + driver.findElement(By.xpath("((.//*[contains(text(),'Tour Date:')])[1]/following::td)[1]")).getText());

			// Get Screenshot
			File InvoiceDetailsPage2 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(InvoiceDetailsPage2,
					new File("C:/TC002_B2CUAEAttractions/InvoiceDetailsPage2.jpg"));		

			//Cancellation charges on invoice
			//Row 1
			System.out.println("The booking Cancellation Charges for Tour 1 =  "
					+ driver.findElement(By.xpath("(.//*[contains(text(),'Cancellation Charges')]/following::td)[1]"))
					.getText()
					+ " is " + driver.findElement(By.xpath("(.//*[contains(text(),'Cancellation Charges')]/following::td)[3]")).getText() + ", If you cancel the Booking FROM " + driver.findElement(By.xpath("(.//*[contains(text(),'Cancellation Charges')]/following::td)[2]")).getText());
			//Row 2
			System.out.println("The booking Cancellation Charges for Tour 1 =  "
					+ driver.findElement(By.xpath("(.//*[contains(text(),'Cancellation Charges')]/following::td)[4]"))
					.getText()
					+ " is " + driver.findElement(By.xpath("(.//*[contains(text(),'Cancellation Charges')]/following::td)[6]")).getText() + ", If you cancel the Booking FROM " + driver.findElement(By.xpath("(.//*[contains(text(),'Cancellation Charges')]/following::td)[5]")).getText());

			// Get Screenshot
			File InvoiceDetailsPage3 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(InvoiceDetailsPage3,
					new File("C:/TC011_DubaiFountainShow_VoucherBooking_CheckSeats/InvoiceDetailsPage3.jpg"));

			driver.findElement(By.xpath(".//*[@id='ProformaInvoiceNew']/div/div/button")).click();
			Thread.sleep(5000);

			//Verify the number of seats are reduced
			driver.findElement(By.xpath(".//*[@class='navbar-brand']")).click();
			Thread.sleep(10000);
			// Click on Search button
			driver.findElement(By.id("btnTourSearch")).click();
			Thread.sleep(5000);
			WebElement PriceLoading1 = wait.until(
					ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='PriceBoxRight']")));
			PriceLoading1.isDisplayed();
			// Select Tour
			driver.findElement(By.id("toursearchtext")).sendKeys("Fountain");
			Thread.sleep(10000);
			driver.findElement(By.xpath(".//*[contains(text(),'Dubai Fountain Show and Lake Ride')]")).click();
			System.out.println("Dubai Fountain Show and Lake Ride Tour is clicked!");
			Thread.sleep(5000);

			// Switch to new window and verify the title	
			for (String winHandle : driver.getWindowHandles()) {
				driver.switchTo().window(winHandle);
			}
			Thread.sleep(5000);

			//Dubai Fountain Walk Bridge Selection
			System.out.println("Tour name 1 = " + driver.findElement(By.xpath("(.//*[@class='TourOP']/div)[1]/span")).getText());
			// Enter the future date after 20 Days
			driver.findElement(By.xpath("(.//*[@class='datepickTD'])[1]/div/div/input")).clear();
			driver.findElement(By.xpath("(.//*[@class='datepickTD'])[1]/div/div/input")).sendKeys(AllDates.Futurdate20(0));
			System.out.println("Date Entered = " + AllDates.Futurdate20(0));
			driver.findElement(By.id("addToCartDetails")).click(); // click on Add To Cart button
			Thread.sleep(15000);
			System.out.println("Book Timing for Show = " + driver
					.findElement(By.xpath("((.//*[@class='toggleBTN'])[2]/following::span)[1]")).getText());		 
			WebElement TimeLoading1 = wait.until(
					ExpectedConditions.visibilityOfElementLocated(By.xpath("(.//*[@class='slotList' ]/li/a/div)[1]")));
			TimeLoading1.isDisplayed();
			driver.findElement(By.xpath("(.//*[@class='slotList' ]/li/a/div)[1]")).click();
			System.out.println("Book Timing = 19:45 pm selected!");		
			System.out.println("Total Seats Available after booking 5 seats previously = " + driver.findElement(By.xpath("(.//*[@class='slotList' ]/li/a/div)[1]")).getText());

			driver.findElement(By.xpath(".//*[contains(text(),'PROCEED')]")).click();
			Thread.sleep(10000);

			WebElement NavToPassengerDetails1 = wait.until(
					ExpectedConditions.visibilityOfElementLocated(By.xpath("((.//*[contains(text(),'Tour Option')])[1])/following::div[1]")));
			NavToPassengerDetails1.isDisplayed();

			// Sign out
			driver.findElement(By.xpath(".//*[@id='liprofile']")).click();
			driver.findElement(By.xpath(".//*[@id='liprofile']/div[@class='dropdown-content']/a[@href='/Signout.aspx']")).click();
			Thread.sleep(5000);

			// Get Screenshot
			File SignOutPage = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(SignOutPage,
					new File("C:/TC011_DubaiFountainShow_VoucherBooking_CheckSeats/SignOutPage.jpg"));
			System.out.println("Scenarios passed --> "
					+ "1. Book Dubai Fountain Show and Lake View after 20 Days."
					+ "2. Verify the seats count is updated after booking some Seats for same day and time.");
			System.out.println("Test Script passed successfully!");

			driver.close();
			driver.quit();

		}
	}
}
