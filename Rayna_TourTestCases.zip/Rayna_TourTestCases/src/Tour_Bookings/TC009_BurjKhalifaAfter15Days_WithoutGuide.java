package Tour_Bookings;

import static org.testng.Assert.assertTrue;
import java.io.File;
import java.util.concurrent.TimeUnit;
import org.apache.maven.shared.utils.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import com.excel.lib.util.Xls_Reader;
import PageObjects.AllDates;
import PageObjects.Menus;
import PageObjects.PassengerDetailsPage;

public class TC009_BurjKhalifaAfter15Days_WithoutGuide {

	public static void main(String[] args) throws Exception {

		BurjKhalifaAfter15Days_WithoutGuide();
	}

		@Test(priority = 0)
		public static void BurjKhalifaAfter15Days_WithoutGuide() throws InterruptedException, Exception {
			//Login
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\Techno\\Desktop\\Automation\\Drivers\\Chrome\\chromedriver.exe");
			WebDriver driver = new ChromeDriver();
			driver.get("https://bookdubaipackage.com/");
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			
			Menus Menu = new Menus (driver);
			PassengerDetailsPage PassengerDT = new PassengerDetailsPage (driver);
					
		    //Valid Login
			WebElement Agent = driver.findElement(By.id("txtAgentcode"));
			WebElement userName = driver.findElement(By.id("txtUsername"));
			WebElement pwd = driver.findElement(By.id("txtPassword"));	
					
			Xls_Reader reader = new Xls_Reader("./src/ExcelResults/SampleExcel.xlsx");
			String sheetName = "login";
					
			int rowCount = reader.getRowCount(sheetName);

			for(int rowNum=2; rowNum<=rowCount; rowNum++){
				String AgentCode = reader.getCellData(sheetName, "Agent", rowNum);
				String loginId = reader.getCellData(sheetName, "username", rowNum);
				String passsword = reader.getCellData(sheetName, "password", rowNum);
						
				System.out.println(AgentCode + " " + loginId + " " + passsword);
				
				Agent.clear();
				Agent.sendKeys(AgentCode);
						
				userName.clear();
				userName.sendKeys(loginId);
						
				pwd.clear();
				pwd.sendKeys(passsword);
						
				driver.findElement(By.id("btnLogin")).click(); 
			Thread.sleep(10000);   	  	

			// Filter for Tour
			driver.findElement(By.id("txtCityNameTour")).clear(); // Enter City or Destination name
			driver.findElement(By.id("txtCityNameTour")).sendKeys("Dubai");

			// Get Screenshot
			File Homepage = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(Homepage, new File("C:/TC009_BurjKhalifaAfter15Days_WithoutGuide/Homepage.jpg"));
			Thread.sleep(5000);

			// Change the currency to AED
			driver.findElement(By.xpath(".//*[@id='sysCurr']")).click();
			driver.findElement(By.xpath(".//ul[@class='dropdown-content']/li/a[@title='AED']")).click();
			System.out.println("AED currency is selected!");
			Thread.sleep(5000);

			// Click on Search button
			driver.findElement(By.id("btnTourSearch")).click();
			Thread.sleep(5000);

			WebDriverWait wait = new WebDriverWait(driver, 10);
			      WebElement PriceLoading = wait.until(
			             ExpectedConditions.visibilityOfElementLocated(By.xpath(".//div[@class='PriceBoxRight']")));
			      PriceLoading.isDisplayed();

			// Select Tour
			driver.findElement(By.id("toursearchtext")).sendKeys("Burj");
			WebElement Tour_Name = driver.findElement(By.xpath(".//*[contains(text(),'Dubai Burj Khalifa Tour')]"));
			Tour_Name.click();
			System.out.println("Dubai Burj Khalifa Tour is clicked!");
			Thread.sleep(5000);

			// Switch to new window and verify the title
			for (String winHandle : driver.getWindowHandles()) {
			driver.switchTo().window(winHandle);
			}
			Thread.sleep(5000);

			System.out.println("Tour Details Fetched for = " + driver
			.findElement(By.xpath(".//div[@class='ProductNameReviews']/h1[contains(text(),'Dubai Burj Khalifa Tour')]"))
			.getText());
			Thread.sleep(5000);

			//124th + 125th Floor Tickets (Non-Prime hours) Selection
			System.out.println("Tour name 1 = " + driver.findElement(By.xpath("(.//*[@class='TourOP']/div)[1]/span")).getText());
			// Transfer Type - Without Transfer
			// Enter the future date
			driver.findElement(By.xpath("(.//*[@class='datepickTD'])[1]/div/div/input")).clear();
			driver.findElement(By.xpath("(.//*[@class='datepickTD'])[1]/div/div/input")).sendKeys(AllDates.Futurdate15(0));
			System.out.println("Date Entered = " + AllDates.Futurdate15(0));
			// PAX = 1 Adult
			// Price calculated for tour 1
			String PriceTour1 = driver.findElement(By.xpath("((.//span[@class='OrigionalPrice'])/span[2])[2]")).getText();
			System.out.println("Price for Tour 1 = " + PriceTour1);

			// Burj Khalifa At the Top Tickets & Sky Views Tour selection
			System.out.println("Tour name 2 = " + driver.findElement(By.xpath("(.//*[@class='TourOP']/div/span)[7]")).getText());
			driver.findElement(By.xpath("(.//*[@class='TourOP']/div)[7]")).click();
			// Transfer Type - Without Transfer
			// Enter the future date
			driver.findElement(By.xpath("(.//*[@class='datepickTD'])[7]/div/div/input")).clear();
			driver.findElement(By.xpath("(.//*[@class='datepickTD'])[7]/div/div/input")).sendKeys(AllDates.Futurdate14(0));
			System.out.println("Date Entered = " + AllDates.Futurdate14(0));
			// PAX = 1 Adult
			// Price calculated for tour 2
			String PriceTour2 = driver.findElement(By.xpath("((.//span[@class='OrigionalPrice'])/span[2])[7]")).getText();
			System.out.println("Price for Tour 2 = " + PriceTour2);

			// Get Screenshot
			File TourDetails = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(TourDetails,
			new File("C:/TC009_BurjKhalifaAfter15Days_WithoutGuide/TourDetails.jpg"));

			driver.findElement(By.id("addToCartDetails")).click(); // click on Add To Cart button
			Thread.sleep(15000);

			// Book timing for tour 1
			System.out.println("Book Timing for Show = " + driver
			.findElement(By.xpath("((.//*[@class='toggleBTN'])[2]/following::span)[1]")).getText());		 
		      WebElement TimeLoading = wait.until(
		             ExpectedConditions.visibilityOfElementLocated(By.xpath("(.//*[@class='slotList' ]/li/a/div)[1]")));
		      TimeLoading.isDisplayed();
			driver.findElement(By.xpath("(.//*[@class='slotList' ]/li/a/div)[1]")).click();
			System.out.println("Book Timing = 10 am selected!");

			driver.findElement(By.xpath(".//*[contains(text(),'PROCEED')]")).click();
            Thread.sleep(5000);
			
			// Book timing for tour 2
			System.out.println("Book Timing for Show = "
			+ driver.findElement(By.xpath("((.//*[@class='toggleBTN'])[2]/following::span)[1]")).getText());
		      WebElement TimeLoading1 = wait.until(
			             ExpectedConditions.visibilityOfElementLocated(By.xpath("(.//*[@class='slotList' ]/li/a/div)[1]")));
		      TimeLoading1.isDisplayed();
			driver.findElement(By.xpath("(.//*[@class='slotList' ]/li/a/div)[1]")).click();
			System.out.println("Book Timing = 10 am selected!");
			driver.findElement(By.xpath(".//*[contains(text(),'PROCEED')]")).click();	
			Thread.sleep(5000);

			//Confirm the Details from Passenger Details Page
			wait.until(
		             ExpectedConditions.visibilityOfElementLocated(By.xpath("(.//*[contains(text(),'Passenger Details')])[1]")));
			System.out.println("Passenger Details Page is opened!");
			PassengerDT.TourName1();
			PassengerDT.TransferType1();
			PassengerDT.BookingDate1();
			PassengerDT.BookingTime1();
			PassengerDT.PAX1();
			PassengerDT.CancellationDate1();
			PassengerDT.AmountTour1();
			
			//Get Screenshot
			File PassengerInfoTour1 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(PassengerInfoTour1, new File("C:/TC009_BurjKhalifaAfter15Days_WithoutGuide/PassengerInfoTour1.jpg")); 
			
			PassengerDT.TourName2();
			PassengerDT.TransferType2();
			PassengerDT.BookingDate2();
			PassengerDT.BookingTime2();
			PassengerDT.PAX2();
			PassengerDT.CancellationDate2();
			PassengerDT.AmountTour2();
			
			//Get Screenshot
			File PassengerInfoTour2 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(PassengerInfoTour2, new File("C:/TC009_BurjKhalifaAfter15Days_WithoutGuide/PassengerInfoTour2.jpg")); 
			
			PassengerDT.FinalPayment();
			PassengerDT.PassengerInfo();		

			// Get Screenshot
			File PassengerInfo = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(PassengerInfo, new File("C:/TC009_BurjKhalifaAfter15Days_WithoutGuide/PassengerInfo.jpg"));

			// Payment Options
			PassengerDT.RadioButtonPayByCreditLimit(); // Radio button for Credit Limit for payment is
			PassengerDT.TermsConditions(); // Accept the Terms & Conditions

			// Get Screenshot
			File PaymentOption = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(PaymentOption, new File("C:/TC009_BurjKhalifaAfter15Days_WithoutGuide/PaymentOption.jpg"));

			// Check the Credit Limit Before Payment
	        Menu.AvailableCrediTLimit();
			Thread.sleep(5000);

			// Get Screenshot
			File CreditLimitBeforePayment = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(CreditLimitBeforePayment,
			new File("C:/TC009_BurjKhalifaAfter15Days_WithoutGuide/CreditLimitBeforePayment.jpg"));

			// Pay on Pay By Credit Limit
			driver.findElement(By.xpath(".//*[contains(text(),'Pay By Credit Limit')]")).click();
			Thread.sleep(5000);

			// Get Screenshot
			File TourDetailsBeforePayment = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(TourDetailsBeforePayment,
			new File("C:/TC009_BurjKhalifaAfter15Days_WithoutGuide/TourDetailsBeforePayment.jpg"));

			// Click on confirm Booking option
			driver.findElement(By.xpath(".//*[contains(text(),'I agree to Confirm my Booking')]")).click();
			Thread.sleep(5000);

			// Tour 1 Details
			System.out.println("The booking is confirmed for Tour 1 = "
			+ driver.findElement(By.xpath("((.//*[contains(text(),'Tour Option')])[1]/following::tbody/tr/td)[1]"))
			.getText()
			+ " with price " + driver.findElement(By.xpath("(.//*[@class='grandprice'])[1]")).getText() + "Status = " + driver.findElement(By.xpath("(.//*[contains(text(),'Booking Status')])[1]/following::td[10]")).getText());
			// Get Screenshot
			File TourDetailsConfirmed1 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(TourDetailsConfirmed1,
			new File("C:/TC009_BurjKhalifaAfter15Days_WithoutGuide/TourDetailsConfirmed1.jpg"));
			
			// Tour 2 Details
			System.out.println("The booking is confirmed for Tour 2 = "
			+ driver.findElement(By.xpath("((.//*[contains(text(),'Tour Option')])[2]/following::tbody/tr/td)[1]"))
			.getText()
			+ " with price " + driver.findElement(By.xpath("(.//*[@class='grandprice'])[2]")).getText() + "Status = " + driver.findElement(By.xpath("(.//*[contains(text(),'Booking Status')])[2]/following::td[10]")).getText());
			// Get Screenshot
			File TourDetailsConfirmed2 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(TourDetailsConfirmed2,
			new File("C:/TC009_BurjKhalifaAfter15Days_WithoutGuide/TourDetailsConfirmed2.jpg"));

			// Download Invoice
			driver.findElement(By.xpath("(.//*[contains(text(),'Download  invoice')])[1]")).click();
			System.out.println("Invoice is printed successfully!");
			Thread.sleep(10000);
			
			//View Invoice
			driver.findElement(By.xpath("(.//*[contains(text(),'View invoice')])[1]")).click();
			System.out.println("Tax Invoice is opened successfully!");
			Thread.sleep(10000);

			// Details verify from Invoice Page
			WebElement Logo = wait.until(
		             ExpectedConditions.visibilityOfElementLocated(By.xpath("((.//*[@class='logopart'])[1]/div/div/div/img)[1]")));
			Logo.isDisplayed();
			
			System.out.println("Agent logo on top left corner is displayed on Invoice details page!");
			driver.findElement(By.xpath("((.//*[@class='logopart'])[1]/div/div/div/img)[2]")).isDisplayed();
			System.out.println("Rayna logo on top right corner is displayed on Invoice details page!");
			
			//Reference Details
			System.out.println(
					"Reference Number = " + driver.findElement(By.xpath("(.//*[@class='ref-details']/div/div/table/tbody/tr/td)[1]")).getText());
			System.out.println(
					"Guest Name = " + driver.findElement(By.xpath("(.//*[@class='ref-details']/div/div/table/tbody/tr/td)[2]")).getText());
			System.out.println(
					"Payment Type = " + driver.findElement(By.xpath("(.//*[@class='ref-details']/div/div/table/tbody/tr/td)[5]")).getText());
			System.out.println(
					"Agent Email Id = " + driver.findElement(By.xpath("(.//*[@class='ref-details']/div/div/table/tbody/tr/td)[6]")).getText());
			System.out.println(
					"Agent Mobile No. = " + driver.findElement(By.xpath("(.//*[@class='ref-details']/div/div/table/tbody/tr/td)[7]")).getText());
						
			// Get Screenshot
			File InvoiceDetailsPage1 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(InvoiceDetailsPage1,
					new File("C:/TC009_BurjKhalifaAfter15Days_WithoutGuide/InvoiceDetailsPage1.jpg"));
			
			//Service Type
			System.out.println(
					"Service Type = " + driver.findElement(By.xpath("(.//*[@class='servic']/div)[2]")).getText());
			
			//Tour Details
			System.out.println("The booking is confirmed for Tour 1 = "
					+ driver.findElement(By.xpath("(.//*[@class='ht-name'])[1]"))
					.getText()
					+ " with price " + driver.findElement(By.xpath("(.//*[@class='ng-scope'])[6]")).getText() + "Dated = " + driver.findElement(By.xpath("((.//*[contains(text(),'Tour Date')])[1]/following::td)[1]")).getText());
					// Tour 2 Confirmation Details
			System.out.println("The booking is confirmed for Tour 2 = "
					+ driver.findElement(By.xpath("(.//*[@class='ht-name'])[2]"))
					.getText()
					+ " with price " + driver.findElement(By.xpath("(.//*[@class='grandprice'])[2]")).getText() + "Dated = " + driver.findElement(By.xpath("((.//*[contains(text(),'Tour Date')])[2]/following::td)[1]")).getText());
						
			// Get Screenshot
			File InvoiceDetailsPage2 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(InvoiceDetailsPage2,
					new File("C:/TC009_BurjKhalifaAfter15Days_WithoutGuide/InvoiceDetailsPage2.jpg"));		
			
			//Cancellation charges on invoice
			//Row 1
			System.out.println("The booking Cancellation Charges for Tour 1 =  "
					+ driver.findElement(By.xpath("(.//*[contains(text(),'Cancellation Charges')]/following::td)[1]"))
					.getText()
					+ " is " + driver.findElement(By.xpath("(.//*[contains(text(),'Cancellation Charges')]/following::td)[3]")).getText() + ", If you cancel the Booking FROM " + driver.findElement(By.xpath("(.//*[contains(text(),'Cancellation Charges')]/following::td)[2]")).getText());
			//Row 2
			System.out.println("The booking Cancellation Charges for Tour 1 =  "
					+ driver.findElement(By.xpath("(.//*[contains(text(),'Cancellation Charges')]/following::td)[4]"))
					.getText()
					+ " is " + driver.findElement(By.xpath("(.//*[contains(text(),'Cancellation Charges')]/following::td)[6]")).getText() + ", If you cancel the Booking FROM " + driver.findElement(By.xpath("(.//*[contains(text(),'Cancellation Charges')]/following::td)[5]")).getText());
		   //Row 3
			System.out.println("The booking Cancellation Charges for Tour 1 =  "
					+ driver.findElement(By.xpath("(.//*[contains(text(),'Cancellation Charges')]/following::td)[7]"))
					.getText()
					+ " is " + driver.findElement(By.xpath("(.//*[contains(text(),'Cancellation Charges')]/following::td)[9]")).getText() + ", If you cancel the Booking FROM " + driver.findElement(By.xpath("(.//*[contains(text(),'Cancellation Charges')]/following::td)[8]")).getText());
			//Row 4
			System.out.println("The booking Cancellation Charges for Tour 1 =  "
					+ driver.findElement(By.xpath("(.//*[contains(text(),'Cancellation Charges')]/following::td)[10]"))
					.getText()
					+ " is " + driver.findElement(By.xpath("(.//*[contains(text(),'Cancellation Charges')]/following::td)[12]")).getText() + ", If you cancel the Booking FROM " + driver.findElement(By.xpath("(.//*[contains(text(),'Cancellation Charges')]/following::td)[11]")).getText());
		
			// Get Screenshot
			File InvoiceDetailsPage3 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(InvoiceDetailsPage3,
					new File("C:/TC009_BurjKhalifaAfter15Days_WithoutGuide/InvoiceDetailsPage3.jpg"));
			
			driver.findElement(By.xpath(".//*[@id='ProformaInvoiceNew']/div/div/button")).click();
			
			System.out.println("Auto Release option available for Tour 1 = " + driver.findElement(By.xpath("(.//*[@class='red-color'])[1]")).getText());
			System.out.println("Auto Release option available for Tour 2 = " + driver.findElement(By.xpath("(.//*[@class='red-color'])[2]")).getText());

			// Click on Voucher Booking for Tour 1
			driver.findElement(By.xpath("(.//*[contains(text(),'Voucher Booking')])[1]")).click();
			Thread.sleep(5000);

			// Issue Voucher
			driver.findElement(By.xpath("(.//*[@class='select_bx'])[3]/input")).sendKeys("Testing Purpose for Dubai Tours");
			driver.findElement(By.xpath(
			"(.//*[@class='bottom-button']/ul/li)[8]/a"))
			.click();
			Thread.sleep(10000);

			// Voucher Details
			// Tour 1 Details
			System.out.println("The booking is confirmed for Tour 1 = "
			+ driver.findElement(By.xpath("((.//*[contains(text(),'Tour Option')])[1]/following::tbody/tr/td)[1]"))
			.getText()
			+ " with price " + driver.findElement(By.xpath("(.//*[@class='grandprice'])[1]")).getText() + "Status = " + driver.findElement(By.xpath("(.//*[contains(text(),'Booking Status')])[1]/following::td[10]")).getText());
			// Get Screenshot
			File TourDetailsAfterVouchering1 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(TourDetailsAfterVouchering1,
			new File("C:/TC009_BurjKhalifaAfter15Days_WithoutGuide/TourDetailsAfterVouchering1.jpg"));
			
			// Tour 2 Details
			System.out.println("The booking is confirmed for Tour 2 = "
			+ driver.findElement(By.xpath("((.//*[contains(text(),'Tour Option')])[2]/following::tbody/tr/td)[1]"))
			.getText()
			+ " with price " + driver.findElement(By.xpath("(.//*[@class='grandprice'])[2]")).getText() + "Status = " + driver.findElement(By.xpath("(.//*[contains(text(),'Booking Status')])[2]/following::td[10]")).getText());
			// Get Screenshot
			File TourDetailsAfterVouchering2 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(TourDetailsAfterVouchering2,
			new File("C:/TC009_BurjKhalifaAfter15Days_WithoutGuide/TourDetailsAfterVouchering2.jpg"));

			// Download Voucher for Tour 1
			driver.findElement(By.xpath("(.//*[contains(text(),'Download Voucher')])[1]")).click();
			Thread.sleep(10000);

			// Download Ticket
			driver.findElement(By.xpath("(.//*[contains(text(),'Download Ticket')])[1]")).click();
			Thread.sleep(10000);
			
			//View Voucher
			driver.findElement(By.xpath("(.//*[contains(text(),'View Voucher')])[1]")).click();
			Thread.sleep(10000);
			
			// Details verify from Voucher Page
			driver.findElement(By.xpath("((.//*[@class='logopart'])[1]/div/div/div/img)[1]")).isDisplayed();
			System.out.println("Rayna logo on top left corner is displayed on Voucher details page!");

			System.out.println(
					"Reference Number = " + driver.findElement(By.xpath("(.//*[@class='ref-rt']/h3/span)[1]")).getText());
			System.out.println("PIN = " + driver.findElement(By.xpath("(.//*[@class='ref-rt']/h3/span)[3]")).getText());

			driver.findElement(By.xpath(".//*[@class='ref-rt']/following::div/img")).isDisplayed();
			System.out.println("Bar Code is displayed on Voucher details page!");

			// Get Screenshot
			File VoucherDetailsPage1 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(VoucherDetailsPage1,
					new File("C:/TC009_BurjKhalifaAfter15Days_WithoutGuide/VoucherDetailsPage1.jpg"));

			System.out.println("Booking Date = " + driver
					.findElement(By.xpath("((.//*[contains(text(),'Booking Date')])[1]/following::td/span)[1]")).getText());
			System.out.println("Tour Date = " + driver
					.findElement(By.xpath("((.//*[contains(text(),'Tour Date')])[1]/following::td/span)[1]")).getText());
			System.out.println("Tour Name = " + driver
					.findElement(By.xpath("((.//*[contains(text(),'Tour Details')])[1]/following::td/span)[2]")).getText());
			System.out.println("Transfer Type = " + driver
					.findElement(By.xpath("(.//*[contains(text(),'Transfer Type')])[2]/following::tbody/tr/td")).getText());
			System.out.println("Guest Name = " + driver
					.findElement(By.xpath("((.//*[contains(text(),'Name')])[2]/following::tbody/tr/td)[1]")).getText());
			System.out.println("Guest Email ID = " + driver
					.findElement(By.xpath("((.//*[contains(text(),'Name')])[2]/following::tbody/tr/td)[2]")).getText());
			System.out.println("Guest Mobile Number = " + driver
					.findElement(By.xpath("((.//*[contains(text(),'Name')])[2]/following::tbody/tr/td)[3]")).getText());

			//Close button - close voucher details
			driver.findElement(By.xpath("(.//*[@class='modal-content']/button)[3]")).click();
			
			// Check the Credit Limit After Payment
			driver.findElement(By.xpath(".//*[@id='agtCreditLimit']")).click();
			Thread.sleep(10000);
			System.out.println("Credit Limit after Payment = " + driver
			.findElement(By.xpath("(.//*[contains(text(),'Available Limit ')]/following-sibling::span/small)[2]"))
			.getText());
			Thread.sleep(5000);

			// Get Screenshot
			File CreditLimitAfterPayment = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(CreditLimitAfterPayment,
			new File("C:/TC009_BurjKhalifaAfter15Days_WithoutGuide/CreditLimitAfterPayment.jpg"));

			//Cancel Booking
			driver.findElement(By.xpath("(.//*[contains(text(),'Cancel Booking')])[1]")).click();
			//Write the reason
	     	driver.findElement(By.id("txtReason")).sendKeys("Testing for cancellation of Booking");
	     	driver.findElement(By.xpath(".//*[contains(text(),'Cancel Booking')]")).click();
	     	driver.findElement(By.xpath(".//*[contains(text(),'Yes')]")).click();
	     	Thread.sleep(10000);  
	     	System.out.println(("Tour Booking Cancelled Successfully..!!!"));
	     	Thread.sleep(10000);   
	     	
	        // Get Screenshot
	     	File TourDetailsAfterCancelling = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	     	FileUtils.copyFile(TourDetailsAfterCancelling,
	     	new File("C:/TC009_BurjKhalifaAfter15Days_WithoutGuide/TourDetailsAfterCancelling.jpg"));
	     	
	     	//Check the Credit Limit After Canceling
	     	driver.findElement(By.xpath(".//li[@id='agtCreditLimit']/a[contains(text(),'Credit Limit')]")).click();
	     	Thread.sleep(10000);
	     	System.out.print("Credit Limit after Cancellation = " + driver.findElement(By.xpath("(.//*[contains(text(),'Available Limit ')]/following-sibling::span/small)[2]")).getText());
	     	Thread.sleep(10000);    
	     	
	     	//Get Screenshot
	     	File CreditLimitAfterCancellation = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	     	FileUtils.copyFile(CreditLimitAfterCancellation, new File("C:/TC009_BurjKhalifaAfter15Days_WithoutGuide/CreditLimitAfterCancellation.jpg")); 
	     			
			// Sign out
			driver.findElement(By.xpath("//a[@href='/Signout.aspx']")).click();
			Thread.sleep(5000);

			// Get Screenshot
			File SignOutPage = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(SignOutPage,
			new File("C:/TC009_BurjKhalifaAfter15Days_WithoutGuide/SignOutPage.jpg"));
			System.out.println("Scenarios passed --> "
			+ "1. Burj Khalifa Tour Without Guide is booked."
			+ "2. Burj Khalifa Tour Without Guide after 15 days is booked."
			+ "3. Burj Khalifa Tours with the Time Slots, 1st tour after 14 days and 2nd tour after 14 days booked/confirmed."
			+ "4. Out of 2 tours- 1st Tour is Vouchered and 2nd Tour is confirmed."
			+ "5. Tour cancellation is done for the vouchered Tour successfully.");
			System.out.println("Test Script passed successfully!");

			driver.close();
			}
		}
}
